# Probable Attack Path and Forensic Analysis (fictional)

## Probable attack path
```mermaid
flowchart LR
    A[1. Developer commits .env<br/>to public GitHub repo] --> B[2. Attacker harvests key<br/>via automated repo scanning]
    B --> C[3. Valid cloud account use<br/>GetCallerIdentity from 198.51.100.23]
    C --> D[4. Discovery<br/>ListBuckets, policies, ListObjects]
    D --> E[5. Collection and exfiltration<br/>1,284 GetObject from 203.0.113.77]
    E --> F[6. Persistence<br/>CreateUser + AdministratorAccess + access key]
    F --> G[7. Defence evasion attempt<br/>StopLogging denied]
    G --> H[8. Detection<br/>alarm acted on 1h32m late]
```

## MITRE ATT&CK mapping (cloud / enterprise)
| Step | Tactic | Technique |
|------|--------|-----------|
| 1-2 | Credential Access | T1552.001 Unsecured Credentials: Credentials in Files |
| 3 | Initial Access | T1078.004 Valid Accounts: Cloud Accounts |
| 4 | Discovery | T1580 Cloud Infrastructure Discovery; T1526 Cloud Service Discovery |
| 5 | Collection / Exfiltration | T1530 Data from Cloud Storage |
| 6 | Persistence / Privilege Escalation | T1136.003 Create Account: Cloud Account; T1098 Account Manipulation |
| 7 | Defense Evasion | T1562.008 Impair Defenses: Disable or Modify Cloud Logs |

## Root cause analysis
| Level | Finding |
|-------|---------|
| Immediate cause | Long-lived access key exposed in a public repository and used by an unauthorised party |
| Contributing technical causes | No secret scanning or push protection; static keys used for a batch job; the key's policy allowed broad S3 read on production export bucket and some IAM read; no S3 data-event logging; alerts not paged |
| Contributing process causes | No policy against personal-repo use for company code; AWS notices to an unmonitored mailbox; no on-call rota; IR plan absent |
| Root cause | Absence of preventive and detective controls around credential lifecycle, combined with weak monitoring ownership |

## Forensic analysis notes
1. **Authenticity of attribution:** the observed IPs are unverified and may be proxies or VPN endpoints; attribution to a person or group is out of scope.
2. **Scope confidence:** download count is derived from S3 server access logs, which are best-effort; true volume could be higher. Mitigated by enabling S3 data events (roadmap item).
3. **Integrity of evidence:** CloudTrail log-file validation passed; log archive hashes recorded.
4. **Persistence sweep:** IAM users, roles, trust policies, access keys, OIDC providers, Lambda functions and EventBridge rules were reviewed in all enabled regions; only `backup-svc-01` was unauthorised.
5. **Data exposure:** exported files were CSV with business and bank-reference fields; classified as confidential. Treat all as disclosed.
6. **Open questions:** was the developer workstation itself compromised; were other secrets in the repo history; were any forks created before takedown.

## Analyst conclusion
High confidence that the incident was opportunistic credential harvesting rather than a targeted intrusion: rapid use after exposure, scripted discovery, bulk download, then a basic persistence attempt. The impact was serious because of excessive permissions and slow detection, not attacker sophistication.
