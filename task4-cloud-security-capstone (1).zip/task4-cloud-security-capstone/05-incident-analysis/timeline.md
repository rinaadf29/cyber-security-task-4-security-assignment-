# Incident Timeline (fictional, all times UTC, 2026-09-22)

**Incident ID:** NP-2026-014 | **Final severity:** SEV1 | **Classification:** Credential exposure leading to cloud data exfiltration

Sources: GitHub commit metadata, AWS CloudTrail management events, S3 server access logs, AWS notification email, IAM credential report, CloudWatch alarm history. Times marked *(est.)* are inferred.

| Time (UTC) | Event | Source | Phase |
|-----------|-------|--------|-------|
| 09:12 | Developer A. Verma commits `.env` containing access key for IAM user `svc-export-batch` to a personal repo `export-tools` | GitHub commit log | Exposure |
| 09:14 | Repository pushed; the repo is **public** | GitHub | Exposure |
| 09:40 | AWS sends "exposed access key" notification to the account's registered contact mailbox (shared, unmonitored) | AWS notification email | Missed detection |
| 11:47 | First use of the key from `198.51.100.23`: `GetCallerIdentity` | CloudTrail | Initial access |
| 11:49 | `ListBuckets`, `GetBucketPolicy`, `GetBucketAcl`, `ListAttachedUserPolicies` | CloudTrail | Discovery |
| 11:55 | `ListObjectsV2` on `nimbuspay-prod-customer-exports` | S3 server access logs | Discovery |
| 12:03-12:41 | 1,284 `GetObject` requests (~4.6 GB) from `203.0.113.77` | S3 server access logs | Exfiltration |
| 12:48 | `CreateUser` `backup-svc-01` from `198.51.100.23` | CloudTrail | Persistence |
| 12:49 | `AttachUserPolicy` (AdministratorAccess) and `CreateAccessKey` for `backup-svc-01` | CloudTrail | Persistence / privilege escalation |
| 13:05 | `StopLogging` attempted on the trail using `backup-svc-01`; **denied** (trail managed from management account) | CloudTrail | Defence evasion (failed) |
| 13:20 | Last observed activity; no further calls *(est. attacker paused)* | CloudTrail | n/a |
| 14:20 | Security analyst notices CloudWatch alarm "CreateUser from non-corporate IP" that fired at 12:48 | Alarm history | **Detection (about 1h 32m after alarm, 2h 33m after first misuse)** |
| 14:35 | Incident declared SEV2 (privileged key misuse); IC assigned | IR log | Identification |
| 14:42 | Key for `svc-export-batch` deactivated; explicit-deny policy and session revocation applied | CloudTrail | Containment |
| 14:55 | `backup-svc-01` access key deactivated, user disabled (retained for evidence) | CloudTrail | Containment |
| 15:10 | Server access logs confirm bulk download; escalated to **SEV1**; Legal and CTO notified | IR log | Identification |
| 15:30 | Public repo reported to GitHub and made private; commit history preserved (hash recorded) | IR log | Containment |
| 16:00 | Evidence collection begins: CloudTrail export, S3 logs, IAM credential report, repo snapshot | Forensics log | Evidence |
| 18:30 | Full IAM/resource sweep complete; no other persistence found in any region | Hunt results | Eradication |
| Day +1 | Secrets rotated; roles replace static keys in batch pipeline; bucket restricted via policy | Change records | Eradication / Recovery |
| Day +2 | Customer-notification decision made with Legal | Legal record | Communication |
| Day +5 | Blameless post-incident review held | Meeting record | Lessons learned |

## Key metrics
| Metric | Value |
|--------|-------|
| Exposure to first misuse | ~2 h 35 m (09:12 to 11:47) |
| First misuse to containment | ~2 h 55 m (11:47 to 14:42) |
| Alarm to human response | ~1 h 32 m |
| Exfiltration window | ~38 min |
| Attacker dwell time (observed) | ~1 h 33 m |

## Detection gaps this timeline reveals
1. No secret scanning or push protection.
2. AWS notification went to an unmonitored mailbox.
3. Alarm routed to a shared inbox with no on-call or paging.
4. S3 data events not enabled; reliance on best-effort server access logs.
5. No GuardDuty alerting tied to paging for anomalous S3 access.
