# Indicators of Compromise and Affected Assets (fictional)

## Indicators of compromise
| Type | Value | Context | Confidence |
|------|-------|---------|-----------|
| IP address | 198.51.100.23 | API calls using leaked key (discovery, persistence) | High |
| IP address | 203.0.113.77 | Bulk S3 `GetObject` downloads | High |
| IAM access key ID | AKIAIOSFODNN7EXAMPLE (AWS documentation sample used as placeholder) | Leaked key of `svc-export-batch` | High |
| IAM user | `backup-svc-01` | Attacker-created persistence account | High |
| IAM access key | Key created for `backup-svc-01` at 12:49 | Persistence credential | High |
| IAM policy attachment | `AdministratorAccess` on `backup-svc-01` | Privilege escalation | High |
| User-agent | Non-corporate CLI/SDK string (e.g., `aws-cli` on Linux) differing from batch job's boto3 agent | Behavioural | Medium |
| Source geography | Region never previously used by `svc-export-batch` | Behavioural | Medium |
| API pattern | `GetCallerIdentity` followed by wide discovery calls within 2 minutes | Behavioural | Medium |
| GitHub artefact | Public repo `export-tools`, commit containing `.env` | Exposure source | High |
| Volume anomaly | 1,284 GetObject calls in 38 min vs daily norm of ~20 | Behavioural | High |
| Failed call | `StopLogging` AccessDenied from `backup-svc-01` | Defence-evasion attempt | High |

## Detection logic derived from IOCs (examples)
- CloudTrail: `eventName in (CreateUser, CreateAccessKey, AttachUserPolicy)` where `sourceIPAddress` not in corporate/NAT ranges.
- CloudTrail: any `StopLogging`, `DeleteTrail`, `PutEventSelectors` event.
- S3: more than N `GetObject` calls per principal per 10 minutes on sensitive buckets.
- IAM: any API call using a key from a new ASN/geography for that principal.

## Affected assets
| Asset | Type | Impact | Confidentiality | Integrity | Availability |
|-------|------|--------|-----------------|-----------|--------------|
| `svc-export-batch` IAM user and key | Identity | Compromised credential | High | Medium | Low |
| `nimbuspay-prod-customer-exports` S3 bucket | Data store | 1,284 objects (~4.6 GB) exfiltrated | **High** | Low | Low |
| Customer export files (≈62 customers) | Data | Business names, reconciliation data, bank reference numbers; no card numbers | **High** | Low | Low |
| `backup-svc-01` IAM user | Identity (attacker-created) | Admin persistence; removed | Medium | Medium | Low |
| AWS account (prod) | Cloud account | Admin-level access held by attacker ~1.5 h | High | Medium | Low |
| Public GitHub repo `export-tools` | Source control | Source of exposure | Medium | Low | Low |
| CloudTrail configuration | Logging | Tamper attempt (blocked) | Low | Medium | Low |
| Developer workstation | Endpoint | Presumed source of commit; to be reviewed | Medium | Low | Low |

## Not affected (verified)
RDS databases (no unusual queries), ECS services and images, SageMaker endpoint, IoT Core fleet, DR region, and log-archive integrity (validated via CloudTrail log-file validation).

## Business impact (assessment)
- Regulatory and contractual notification obligations for ~62 customers.
- Reputational damage and potential contract-termination risk.
- Estimated response cost (staff time, external counsel, monitoring) and customer-credit exposure; see executive deck for planning figures.
