# Cloud Security Checklist

Status key: ☐ not done, ◐ partial, ☑ done. "NimbusPay baseline" shows the state at the time of the incident.

## 1. Identity and access
| # | Control | Baseline |
|---|---------|----------|
| 1.1 | Root account secured: MFA, no access keys, alerts on use | ◐ |
| 1.2 | Humans use SSO (IAM Identity Center) with MFA; no IAM users for people | ◐ |
| 1.3 | Phishing-resistant MFA (FIDO2) for admins | ☐ |
| 1.4 | Workloads use IAM roles; no long-lived access keys | ☐ |
| 1.5 | Least-privilege policies; no `*:*` wildcards | ☐ |
| 1.6 | Permission boundaries and SCPs enforced org-wide | ☐ |
| 1.7 | Access keys (if unavoidable) rotated ≤ 90 days and inventoried | ☐ |
| 1.8 | Quarterly access reviews; joiner/mover/leaver process | ◐ |
| 1.9 | IAM Access Analyzer enabled for external and unused access | ☐ |

## 2. Storage and data protection
| # | Control | Baseline |
|---|---------|----------|
| 2.1 | S3 Block Public Access on at account level | ☐ |
| 2.2 | Default encryption with KMS keys; key policies reviewed | ◐ |
| 2.3 | Bucket policies enforce TLS and restrict to VPC endpoint/roles | ☐ |
| 2.4 | Versioning and MFA-delete/Object Lock on critical buckets | ☐ |
| 2.5 | Data classified; Macie scans sensitive buckets | ☐ |
| 2.6 | RDS and EBS encrypted; snapshots not public | ☑ |
| 2.7 | Customer exports expire automatically (lifecycle rules) | ☐ |

## 3. Network controls
| # | Control | Baseline |
|---|---------|----------|
| 3.1 | Three-tier VPC; databases in isolated subnets | ☑ |
| 3.2 | No public IPs on app/data resources | ◐ |
| 3.3 | Security groups: no `0.0.0.0/0` to admin ports | ◐ |
| 3.4 | VPC endpoints for S3, KMS, Secrets Manager, ECR | ☐ |
| 3.5 | WAF with managed rules and rate limiting on edge | ◐ |
| 3.6 | TLS 1.2+ enforced everywhere; HSTS on web | ☑ |
| 3.7 | Egress filtering/controlled NAT for workloads | ☐ |

## 4. Logging
| # | Control | Baseline |
|---|---------|----------|
| 4.1 | Org-wide CloudTrail (all regions), log-file validation | ◐ |
| 4.2 | S3 data events enabled for sensitive buckets | ☐ |
| 4.3 | VPC Flow Logs, ALB, WAF, and RDS audit logs enabled | ◐ |
| 4.4 | Logs centralised in a separate Log Archive account with Object Lock | ☐ |
| 4.5 | Retention ≥ 12 months (90 days hot, remainder archived) | ☐ |
| 4.6 | Time synchronised (NTP/Amazon Time Sync) across systems | ☑ |

## 5. Monitoring and detection
| # | Control | Baseline |
|---|---------|----------|
| 5.1 | GuardDuty enabled in all accounts/regions | ◐ |
| 5.2 | Security Hub with CIS AWS Foundations / AWS FSBP standards | ☐ |
| 5.3 | AWS Config rules for drift and misconfiguration | ◐ |
| 5.4 | Alerts: root use, `CreateUser`, `CreateAccessKey`, policy changes, logging disabled, unusual S3 download volume | ◐ |
| 5.5 | Alerts route to on-call with defined SLAs | ☐ |
| 5.6 | Detection use cases reviewed and tested quarterly | ☐ |

## 6. Secrets management
| # | Control | Baseline |
|---|---------|----------|
| 6.1 | Secrets stored in Secrets Manager/Parameter Store (SecureString) | ◐ |
| 6.2 | Automatic rotation for DB and API credentials | ☐ |
| 6.3 | Pre-commit and CI secret scanning (e.g., gitleaks) | ☐ |
| 6.4 | GitHub secret scanning and push protection enabled | ☐ |
| 6.5 | Documented process to revoke and rotate leaked secrets within 1 hour | ☐ |

## 7. Backups and recovery
| # | Control | Baseline |
|---|---------|----------|
| 7.1 | Automated RDS backups and point-in-time recovery | ☑ |
| 7.2 | Cross-region and cross-account backup copies | ☐ |
| 7.3 | Backups immutable (Backup Vault Lock / Object Lock) | ☐ |
| 7.4 | RTO/RPO defined per service | ◐ |
| 7.5 | Restore tested at least twice a year | ☐ |

## 8. Incident readiness
| # | Control | Baseline |
|---|---------|----------|
| 8.1 | Approved IR plan with roles, severities, and contacts | ☐ |
| 8.2 | Playbooks for credential leak, ransomware, data exfiltration | ☐ |
| 8.3 | Pre-provisioned forensic/IR role with read-only cross-account access | ☐ |
| 8.4 | Evidence-handling procedure and chain-of-custody forms | ☐ |
| 8.5 | Tabletop exercise at least twice a year | ☐ |
| 8.6 | Legal, PR, and customer-notification contacts documented | ◐ |
| 8.7 | AWS Support plan adequate for incidents | ◐ |

**Baseline summary:** of 52 controls, 5 done, 16 partial, 31 not done. This gap profile feeds the 90-day roadmap.
