# Professional Cybersecurity Career Section

## 1. Target roles
Cloud Security Analyst, Security Operations (SOC) Analyst, Incident Responder / DFIR Analyst, DevSecOps Engineer, GRC Analyst.

## 2. Skills identified through this capstone
| Area | Skills demonstrated or required |
|------|--------------------------------|
| Cloud security | AWS IAM, VPC design, KMS, S3 security, CloudTrail, GuardDuty, Security Hub |
| Governance | NIST CSF, ISO/IEC 27001, CIS Controls mapping, risk assessment |
| Incident response and forensics | Triage, timeline building, IOC extraction, MITRE ATT&CK mapping, evidence handling |
| DevSecOps | CI/CD security, SAST/SCA, secret scanning, IaC scanning, container security |
| AI / IoT security | Model and data protection, device identity, firmware integrity |
| Professional skills | Technical writing, executive communication, prioritisation, ethics and legal awareness |
| Tools | Python and Bash scripting, Git/GitHub, Linux, SQL/log querying, Docker, Terraform basics |

## 3. Certifications roadmap
| Stage | Certification | Why |
|-------|---------------|-----|
| Entry | CompTIA Security+ | Broad foundation |
| Entry/Cloud | AWS Certified Cloud Practitioner, then AWS Security Specialty | Cloud fundamentals and security depth |
| SOC / DFIR | CompTIA CySA+, GIAC GCIH or GCFE (later) | Detection, response, forensics |
| Cloud | Microsoft AZ-500 or Google Professional Cloud Security Engineer | Multi-cloud coverage |
| GRC | ISO/IEC 27001 Lead Implementer/Auditor | Governance and audit |
| Advanced | CISSP (after required experience), OSCP for offensive depth | Seniority and breadth |

Confirm current exam details and prerequisites on each vendor's site.

## 4. Next-learning priorities (next 6-12 months)
1. Hands-on AWS security labs in a personal sandbox account with billing alerts.
2. Practise on legal training platforms and CTFs (TryHackMe, Hack The Box, CloudGoat-style labs).
3. Learn log analysis and detection engineering (SIEM queries, Sigma rules).
4. Build a small DevSecOps pipeline on a self-built app with gitleaks, Semgrep, Trivy.
5. Study forensics fundamentals (disk and memory analysis, evidence handling).
6. Write public technical notes or a portfolio repo (this capstone counts).
7. Develop communication skills: executive summaries and incident reports.

## 5. Professional practice and ethics
- Test only with authorisation and in training environments.
- Follow responsible-disclosure norms and confidentiality.
- Respect privacy and data-minimisation principles.
- Join communities (OWASP chapters, local security meetups, ISACA/ISC2 student groups) and keep learning.

## 6. Personal 12-month plan
| Quarter | Goal |
|---------|------|
| Q1 | Security+ study; build AWS lab; complete capstone repo |
| Q2 | AWS Security Specialty prep; CTF participation; internship applications |
| Q3 | DFIR/SOC lab projects; CySA+ or equivalent |
| Q4 | Portfolio polish; networking; evaluate specialisation (cloud, DFIR, GRC) |
