# 90-Day Prioritised Security Improvement Roadmap

Priority: **P1** critical (do first), **P2** high, **P3** medium. Effort: S (≤3 days), M (≤2 weeks), L (≤6 weeks). Every item traces to an incident finding or checklist gap.

## Phase 1: Days 0-30 "Stop the bleeding"
| # | Action | Owner | Effort | Priority | Expected outcome | Traces to |
|---|--------|-------|--------|----------|------------------|-----------|
| 1 | Enable GitHub secret scanning and push protection org-wide; add gitleaks pre-commit and CI check | DevOps Lead | S | P1 | Secrets blocked before reaching a remote | Root cause, T9 |
| 2 | Inventory and rotate all IAM access keys; disable unused; begin replacing with roles | Cloud Engineer | M | P1 | No unmanaged static keys in prod | T1, checklist 1.4, 1.7 |
| 3 | Route security alarms and AWS notices to paged on-call; create monitored security mailbox | Head of Security | S | P1 | Alarm-to-response under 15 minutes | Detection gap |
| 4 | Enable org-wide CloudTrail with S3 data events on sensitive buckets, GuardDuty and Security Hub | Cloud Engineer | M | P1 | Complete visibility of data access | 4.1, 4.2, 5.1 |
| 5 | Apply S3 Block Public Access and restrictive bucket policy (VPC endpoint/roles) on exports bucket; lifecycle expiry on exports | Cloud Engineer | S | P1 | Reduced data exposure | T8 |
| 6 | Approve IR plan v1.0 and run first tabletop | Head of Security | S | P1 | Defined roles, tested process | 8.1, 8.5 |
| 7 | Add SCPs: deny CloudTrail changes, deny IAM user creation outside approved roles | Cloud Engineer | S | P1 | Block persistence and log tampering | T5, T13 |
| 8 | Complete customer-notification decisions with Legal | Legal / CISO | S | P1 | Compliance with obligations | Incident impact |

## Phase 2: Days 31-60 "Build the foundations"
| # | Action | Owner | Effort | Priority | Expected outcome | Traces to |
|---|--------|-------|--------|----------|------------------|-----------|
| 9 | Move human access to SSO with MFA; FIDO2 keys for admins | IT Lead | M | P1 | Strong authentication | T2 |
| 10 | Least-privilege IAM review; permission boundaries; IAM Access Analyzer findings cleared | Cloud Engineer | L | P2 | Reduced blast radius | T13, R2 |
| 11 | Centralise logs in Log Archive account with Object Lock; 12-month retention | Cloud Engineer | M | P2 | Tamper-resistant evidence | 4.4, 4.5 |
| 12 | GitHub Actions to OIDC roles; remove stored keys from pipelines | DevOps Lead | M | P2 | Keyless CI/CD | T15 |
| 13 | Secrets to Secrets Manager with rotation | DevOps Lead | M | P2 | Managed secret lifecycle | 6.1, 6.2 |
| 14 | Add SAST, SCA, IaC and container scanning gates to CI | DevOps Lead | L | P2 | Fewer vulnerabilities shipped | T4, R6 |
| 15 | Build detection use cases (new-IP key use, bulk S3 download, IAM changes) | Security Analyst | M | P2 | Faster detection | IOC-derived |
| 16 | Create evidence account and finalise forensic runbooks | Forensics Lead | M | P2 | Defensible evidence handling | Plan 06 |

## Phase 3: Days 61-90 "Mature and verify"
| # | Action | Owner | Effort | Priority | Expected outcome | Traces to |
|---|--------|-------|--------|----------|------------------|-----------|
| 17 | Cross-region, cross-account immutable backups; first restore test | Cloud Engineer | M | P2 | Proven recoverability | R10 |
| 18 | VPC endpoints, egress controls, WAF tuning | Network Engineer | M | P2 | Reduced lateral movement and exfil paths | R7 |
| 19 | AI/IoT: split ML roles, enable Device Defender, fleet inventory, signed model/firmware | ML Lead / IoT Lead | L | P2 | Reduced AI/IoT risk | Plan 08 |
| 20 | Data classification and Macie scanning of sensitive buckets | Data Owner | M | P3 | Know where sensitive data lives | R3 |
| 21 | Security awareness and secure-coding training; security champions | Security Lead | S | P3 | Fewer human-error incidents | CIS 14 |
| 22 | Start ISMS scoping, risk register, Statement of Applicability draft | CISO | M | P3 | Governance roadmap for ISO 27001 | Mapping |
| 23 | Independent review or authorised penetration test of prod | CISO | M | P3 | External assurance | DevSecOps |
| 24 | Executive review of metrics and 90-day results | CISO | S | P3 | Sustained funding and focus | Governance |

## Resourcing summary
| Phase | Items | Estimated effort (person-days) | Indicative cost (planning figure) |
|-------|-------|-------------------------------|-----------------------------------|
| 0-30 | 8 | ~35 | Mostly tooling already licensed; low |
| 31-60 | 8 | ~70 | Medium (hardware keys, scanning tools) |
| 61-90 | 8 | ~60 | Medium (backup storage, external test) |

## Success measures at Day 90
- 100% of repos with push protection; 0 static keys in production workloads.
- Mean time to detect high-severity cloud alerts under 15 minutes.
- Tabletop completed at least twice; first restore test passed.
- All P1 and 80% of P2 actions complete.
