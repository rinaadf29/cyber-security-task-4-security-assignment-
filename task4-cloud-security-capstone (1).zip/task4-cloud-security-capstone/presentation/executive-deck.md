---
marp: true
theme: default
paginate: true
header: "NimbusPay | Incident NP-2026-014 | Confidential (fictional)"
---

# Cloud Security Incident and 90-Day Improvement Plan
**Executive briefing**
Lead Security Analyst, NimbusPay
*Fictional scenario for academic assessment*

---

## What happened
- A developer committed a cloud access key to a **public** GitHub repo.
- Within ~2.5 hours it was used by an unknown party.
- **~4.6 GB of customer export data (~62 customers) was downloaded.**
- The attacker created a hidden admin account to keep access.
- We contained it in ~3 hours; the alarm had fired 1.5 hours earlier.

---

## Timeline at a glance
| Time (UTC) | Event |
|---|---|
| 09:12 | Key committed to public repo |
| 11:47 | First misuse of key |
| 12:03-12:41 | Customer data downloaded |
| 12:48 | Attacker creates admin user |
| 14:20 | Analyst sees alarm (fired 12:48) |
| 14:42 | Key disabled: contained |
| 15:10 | Escalated to SEV1 |

---

## Business impact
- **Data:** confidential customer reconciliation and bank-reference data disclosed. No card numbers.
- **Legal and contractual:** notification duties to ~62 customers; regulator reporting under review.
- **Trust:** reputational and contract-renewal risk.
- **Operations:** no outage; systems and databases unaffected.

---

## Why it happened (root cause)
1. Long-lived keys in use; no secret scanning
2. Key had broader access than its job needed
3. Alerts and AWS warnings went to unmonitored inboxes
4. No incident-response plan or on-call rota

**Not sophistication. Gaps in basics.**

---

## Key risks today
| Risk | Level |
|---|---|
| Leaked or long-lived credentials | Critical |
| Over-broad permissions | High |
| Weak detection and response ownership | High |
| Insecure CI/CD and dependencies | High |
| Unmonitored AI model and IoT fleet | Medium-High |
| Untested backups | Medium |

---

## Target secure architecture
- Separate AWS accounts: prod, security, immutable log archive
- SSO and MFA for people; **roles, not keys,** for workloads
- Private networking, encrypted data, WAF at the edge
- Central logging, GuardDuty, Security Hub
- Keyless CI/CD with automated security gates

---

## Framework alignment
- **NIST CSF 2.0:** Govern, Identify, Protect, Detect, Respond, Recover
- **ISO/IEC 27001:** path to a certifiable ISMS
- **CIS Controls v8:** target IG2

All 25 priority controls are mapped to all three frameworks.

---

## 90-day roadmap
| Days | Focus | Highlights |
|---|---|---|
| 0-30 | Stop the bleeding | Secret scanning, key rotation, paged alerts, SCPs, IR plan |
| 31-60 | Foundations | SSO and FIDO2, least privilege, log archive, keyless CI/CD |
| 61-90 | Mature and verify | Immutable backups, AI/IoT hardening, pen test, ISMS scoping |

---

## Recommended investments
| Investment | Why | Cost level |
|---|---|---|
| Secret scanning and CI security tooling | Prevents recurrence | Low-Medium |
| 24x7 alert paging / managed detection | Cuts response time | Medium |
| FIDO2 hardware keys for admins | Stops credential phishing | Low |
| Immutable log and backup storage | Evidence and recovery | Medium |
| External penetration test | Independent assurance | Medium |
| Security training and champions | Reduces human error | Low |

---

## How we will measure success
- 0 static keys in production
- 100% of repos with push protection
- High-severity alerts triaged in **under 15 minutes**
- Two tabletop exercises and a passed restore test
- All P1 and 80% of P2 actions done by Day 90

---

## Decisions requested today
1. Approve the 90-day roadmap and budget envelope
2. Name an executive owner for security
3. Approve customer-notification plan (with Legal)
4. Fund 24x7 alerting and the external test

**Thank you. Questions?**
