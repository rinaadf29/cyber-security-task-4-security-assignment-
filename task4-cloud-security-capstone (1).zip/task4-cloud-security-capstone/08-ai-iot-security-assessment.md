# AI and IoT Security Assessment

Applies to NimbusPay's fraud-scoring ML model (SageMaker) and ~300 card-reader / POS terminals connected via AWS IoT Core.

## Part A: AI-enabled systems

### A1. Data risks
| Risk | Description | Mitigation |
|------|-------------|-----------|
| Training-data poisoning | Malicious or mislabelled data skews fraud decisions | Data provenance, access control on training buckets, validation and outlier checks, versioned datasets |
| Sensitive data leakage | Personal/financial data in training sets or model output | Minimise and pseudonymise data, encryption (KMS), retention limits, Macie scans |
| Privacy and compliance | Lawful basis, purpose limitation, data-subject rights | Data-protection impact assessment, documented purposes |
| Inference-time data exposure | Prompts, features or logs retain sensitive data | Log redaction, short retention, access controls |

### A2. Identity and access risks
| Risk | Mitigation |
|------|-----------|
| Over-privileged ML roles (training role can read all production data) | Separate roles for training, deployment and inference; least privilege |
| Shared notebook credentials | SSO, per-user roles, no static keys, session time limits |
| Unauthenticated inference endpoint | Private VPC endpoint, IAM-authenticated calls only, throttling |

### A3. Model trust risks
| Risk | Mitigation |
|------|-----------|
| Model tampering or substitution | Signed model artifacts, hash verification, restricted write to model registry |
| Adversarial inputs / evasion | Input validation, rate limiting, adversarial testing, ensemble or rule-based backstops |
| Model extraction/theft via queries | Query throttling, anomaly detection on usage, response minimisation |
| Supply-chain risk (pretrained models, ML libraries) | Approved sources only, SCA scans, SBOM including ML dependencies |
| Prompt injection (if LLM components are added) | Treat model output as untrusted, separate instructions from data, least-privilege tools, human approval for sensitive actions |
| Bias and unfair decisions | Fairness testing, human review path for declined transactions |

### A4. Monitoring risks
| Risk | Mitigation |
|------|-----------|
| Model drift unnoticed | Drift and performance monitoring, alert thresholds |
| No audit of model changes | Model registry with approvals and change history |
| Abuse not detected | Logging of inference requests (metadata), anomaly alerts, incident playbook for model abuse |

## Part B: IoT devices (POS terminals)

### B1. Device identity and trust
| Risk | Mitigation |
|------|-----------|
| Cloned or rogue device | Unique X.509 certificate per device, private key in secure element/TPM, IoT Core policy bound to certificate/thing |
| Shared credentials across fleet | Prohibit; per-device identity only |
| Lost or stolen device | Certificate revocation, device deactivation process, remote wipe where supported |

### B2. Firmware and update integrity
| Risk | Mitigation |
|------|-----------|
| Malicious or tampered firmware | Secure boot, signed firmware, verified OTA updates (AWS IoT Jobs with code signing) |
| Unpatched vulnerabilities | Update SLA, vendor SBOM, end-of-life tracking |
| Default or hard-coded passwords | No default credentials; unique credentials on provisioning; disabled debug ports |

### B3. Data and communication risks
| Risk | Mitigation |
|------|-----------|
| Interception of traffic | Mutual TLS 1.2+, certificate pinning, no cleartext protocols |
| Excess data stored on device | Data minimisation, encryption at rest, no card-data persistence beyond requirement |
| Over-broad cloud permissions | IoT policies scoped to the device's own topics |

### B4. Monitoring risks
| Risk | Mitigation |
|------|-----------|
| Compromised device unseen | Device Defender: behavioural baselines, alerts on unusual traffic, connection patterns, certificate misuse |
| No fleet inventory | Asset register with firmware versions and last-seen time |
| Slow response | Playbook to quarantine devices (detach policy, revoke cert) |

## Part C: Cross-cutting risk summary
| ID | System | Risk | Likelihood | Impact | Priority |
|----|--------|------|-----------|--------|----------|
| AI-1 | ML | Over-privileged training/inference roles | Medium | High | High |
| AI-2 | ML | Model artifact tampering | Low | High | Medium |
| AI-3 | ML | Data leakage from training sets | Medium | High | High |
| AI-4 | ML | Undetected drift or abuse | Medium | Medium | Medium |
| IoT-1 | Devices | Cloned or rogue device | Medium | Medium | Medium |
| IoT-2 | Devices | Unsigned or outdated firmware | Medium | High | High |
| IoT-3 | Devices | No fleet monitoring | High | Medium | High |

## Part D: Recommended actions
1. Split ML IAM roles and move training data behind least-privilege access (Days 1-45).
2. Enable model registry with signed artifacts and approval workflow (Days 30-75).
3. Enable IoT Device Defender and complete a fleet inventory (Days 15-45).
4. Enforce signed OTA firmware updates and certificate revocation process (Days 45-90).
5. Add AI/IoT scenarios to the incident-response tabletop.
