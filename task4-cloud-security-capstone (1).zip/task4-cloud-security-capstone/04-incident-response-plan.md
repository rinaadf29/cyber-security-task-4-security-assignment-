# Incident-Response Plan (NimbusPay)

**Version:** 1.0 | **Owner:** Head of Security | **Review cycle:** every 6 months and after every major incident
**Aligned to:** NIST SP 800-61 lifecycle, ISO/IEC 27035, NIST CSF RS/RC functions

## 1. Purpose and scope
Defines how NimbusPay prepares for, detects, contains, eradicates and recovers from security incidents affecting cloud workloads, endpoints, SaaS, CI/CD, IoT and AI components.

## 2. Roles and responsibilities
| Role | Responsibilities |
|------|-----------------|
| Incident Commander (IC) | Owns the incident, sets priorities, authorises containment |
| Security Analyst (Lead) | Triage, investigation, evidence collection |
| Cloud/Platform Engineer | Executes containment and recovery in AWS |
| Application Owner | Business and technical context for affected service |
| Forensics Lead | Evidence handling, chain of custody |
| Communications Lead | Internal and external messaging |
| Legal / Compliance | Regulatory and contractual notification decisions |
| Executive Sponsor (CTO/CEO) | Business decisions, approvals, customer escalation |
| Scribe | Maintains the incident log |

## 3. Severity levels
| Level | Definition | Example | Response target | Notify |
|-------|-----------|---------|-----------------|--------|
| SEV1 Critical | Confirmed data breach or service-wide compromise | Customer data exfiltrated | Respond in 15 min; IC assigned | CEO, Legal, Board |
| SEV2 High | Probable compromise of privileged account or sensitive system | Leaked admin key in use | 30 min | CTO, Legal |
| SEV3 Medium | Contained suspicious activity, limited impact | Malware on one endpoint | 4 hours | Security lead |
| SEV4 Low | Policy violation or false-positive candidate | Failed login spike | Next business day | Security queue |

## 4. Phase 1: Preparation
- Approve this plan, contacts list and escalation matrix; keep an offline copy.
- Maintain asset inventory, data classification and network/IAM diagrams.
- Enable and centralise logging (CloudTrail incl. S3 data events, VPC Flow, GuardDuty, WAF, RDS audit).
- Pre-provision a **read-only IR role** with cross-account access and a **break-glass containment role**, both MFA-protected and alarmed.
- Prepare playbooks: credential leak, data exfiltration, ransomware, compromised workload, malicious dependency.
- Prepare a forensic toolkit and evidence-handling procedures (see `06-forensics/`).
- Run tabletop exercises twice a year; train on-call staff.
- Establish out-of-band communication channel (e.g., separate chat/phone bridge) in case corporate systems are compromised.

## 5. Phase 2: Identification
1. **Detect:** alerts (GuardDuty, CloudTrail rules, SIEM), employee reports, third-party notifications (e.g., GitHub secret-scanning alerts, researchers).
2. **Triage:** validate whether the event is a true incident; check source IP, principal, API calls, and affected resources.
3. **Classify:** assign severity and incident type; open incident record with timestamp (UTC).
4. **Scope:** list affected identities, accounts, resources and data; determine if data was accessed or exfiltrated.
5. **Declare:** IC formally declares the incident and starts the incident log.
6. **Preserve first:** snapshot volatile evidence before disruptive actions where safe (see evidence plan).

## 6. Phase 3: Containment
**Short-term (minutes):**
- Disable or deactivate the compromised access key; do not delete until evidence is captured.
- Attach an explicit-deny inline policy to the compromised principal; revoke active sessions (IAM "Revoke older sessions").
- Disable rogue IAM users/roles created by the attacker.
- Block malicious IPs at WAF/NACL as an interim measure.
- Restrict affected S3 buckets (deny-all except IR role).

**Long-term:**
- Segment or isolate affected workloads (quarantine security group; no deletion).
- Rotate related secrets and credentials (DB, API, signing keys).
- Increase logging and monitoring on related identities and resources.

## 7. Phase 4: Eradication
- Remove attacker persistence: unknown IAM users, roles, access keys, trust-policy changes, Lambda functions, EC2/ECS tasks, rogue OIDC providers.
- Remove leaked secrets from source history (rewrite history and force-rotate; assume the secret is compromised regardless).
- Patch exploited weaknesses; fix IAM policies and bucket configuration.
- Re-scan environment (Config, Security Hub, Access Analyzer) for residual misconfiguration.
- Validate eradication through a hunt for IOCs across all accounts and regions.

## 8. Phase 5: Recovery
- Restore services from known-good IaC and images; restore data from verified clean backups if integrity is in doubt.
- Reissue credentials via roles/SSO; re-enable services in stages.
- Monitor closely for 30 days for re-compromise (heightened alerting).
- Confirm business owner sign-off before declaring recovery complete.

## 9. Phase 6: Lessons learned
- Blameless post-incident review within 5 business days of closure.
- Produce a report: timeline, root cause, impact, what worked and what did not, corrective actions with owners and due dates.
- Update detection rules, playbooks, training and the risk register.
- Track corrective actions to closure; report to management.

## 10. Communication and notification
| Audience | When | Owner |
|----------|------|-------|
| Internal IR team | Immediately | IC |
| Executives | SEV1/SEV2 within 1 hour | IC |
| Legal/Compliance | On suspicion of personal or regulated data exposure | IC |
| Affected customers | As required by contract/law, after Legal approval | Communications Lead |
| Regulators | Per applicable law (e.g., Indian DPDP Act obligations, CERT-In 6-hour reporting for specified incidents) | Legal |
| AWS Support | If provider assistance or abuse reporting is needed | Cloud Engineer |

> Confirm current legal reporting timelines with Legal counsel; requirements change.

## 11. Playbook excerpt: leaked cloud credential
1. Identify key owner and last use (IAM credential report, CloudTrail `lastUsed`).
2. Deactivate key and deny sessions (containment).
3. Query CloudTrail for all actions by the key (all regions) from first exposure time.
4. Enumerate created resources and IAM changes; remove persistence.
5. Determine data accessed (S3 data events, server access logs).
6. Rotate dependent secrets; replace with roles.
7. Notify per severity; document; run lessons learned.

## 12. Metrics
Mean time to detect (MTTD), mean time to contain (MTTC), mean time to recover (MTTR), number of incidents by type, percentage of corrective actions closed on time.
