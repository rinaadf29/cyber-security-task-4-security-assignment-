# Cloud Security, Incident Response and Cybersecurity Capstone Report

**Organisation (fictional):** NimbusPay
**Prepared by:** Lead Security Analyst (Rinad)
**Course:** Cybersecurity, Task 4 (Modules 13-15)
**Classification:** Confidential, academic exercise only

> All names, IP addresses, account IDs, data volumes and dates in this report are fictional. No real system was scanned, tested or attacked, and no real data was collected.

## Table of contents
**Part I: Report**
1. Executive summary
2. Introduction, scope and method
3. Secure cloud architecture and threat model
4. Governance and framework alignment
5. Incident analysis
6. Response, forensics and recovery
7. DevSecOps, AI and IoT
8. Prioritised roadmap and investment
9. Professional development

**Part II: Key deliverables** (reference architecture, incident timeline, attack path, 90-day roadmap; remaining deliverables are separate files in the repository)

**Part III: Conclusion and references**

---
# Part I: Report

## 1. Executive summary
NimbusPay, a fictional fintech software company with about 150 staff, is moving its critical services to Amazon Web Services while building a more mature security and governance programme. During this transition a security incident (NP-2026-014) occurred. A developer accidentally committed an AWS access key to a public GitHub repository. About two and a half hours later the key was used by an unknown party to explore the cloud account, download roughly 4.6 GB of customer export data belonging to around 62 customers, and create a new administrator account to keep access.

The attacker's actions were not sophisticated. The damage was made possible by long-lived credentials, permissions broader than the task required, missing secret scanning, and alerts that nobody was paged to act on. An alarm for the suspicious account creation fired at 12:48 UTC but was not seen until 14:20 UTC. Containment was complete at 14:42 UTC for the original key and 14:55 UTC for the attacker-created account.

This report presents a complete response and improvement programme: a secure target architecture and threat model, a cloud security checklist, mappings to NIST CSF 2.0, ISO/IEC 27001 and CIS Controls, an incident-response plan, a timeline and forensic analysis, an evidence-handling plan, a DevSecOps plan, an AI and IoT assessment, and a prioritised 90-day roadmap with owners and effort estimates.

**The most important recommendations are:**
1. Eliminate long-lived keys and block secrets from reaching source control.
2. Route security alerts to a paged, monitored on-call process.
3. Enforce least privilege and guardrails (SCPs) across all AWS accounts.
4. Centralise immutable logging and enable data-event visibility on sensitive storage.
5. Approve and rehearse the incident-response plan.

Delivering the 90-day roadmap would remove the conditions that allowed this incident and measurably shorten detection and response times.

## 2. Introduction, scope and method

### 2.1 Objective
To act as lead security analyst: design the security programme, analyse the incident and recommend prioritised improvements that leaders can approve and fund.

### 2.2 Scope
The scope covers NimbusPay's representative production workload on AWS (web front end, containerised services, PostgreSQL database, S3 storage, an ML fraud model and an IoT terminal fleet), its CI/CD pipeline on GitHub, and the people and processes around them.

### 2.3 Method
1. **Model the workload** and its trust boundaries.
2. **Identify threats** using STRIDE and rate them by likelihood and impact.
3. **Assess control gaps** with a cloud security checklist (52 controls; 5 fully in place, 16 partial, 31 absent).
4. **Map controls to frameworks** to link technical work to governance expectations.
5. **Reconstruct the incident** from logs and metadata into a timeline, indicators of compromise and an attack path, mapped to MITRE ATT&CK.
6. **Define response, forensic and DevSecOps processes** that would have prevented or shortened the incident.
7. **Prioritise remediation** into a 90-day roadmap with owners, effort and outcomes.

### 2.4 Ethics and safety
The work is entirely fictional. No scanning, exploitation, credential attack, phishing, malware or data collection was carried out against any real system. Evidence handling follows a minimum-necessary principle.

## 3. Secure cloud architecture and threat model
The target design uses a multi-account AWS organisation (management, security, log archive, shared services, production, non-production). Production uses a three-tier VPC: public subnets hold only the load balancer and NAT; application containers run on Fargate in private subnets using task roles instead of keys; the database sits in isolated subnets with KMS encryption. Traffic to S3, KMS, Secrets Manager and ECR flows through VPC endpoints. CloudFront with AWS WAF protects the edge. People sign in through IAM Identity Center with MFA; GitHub Actions authenticates to AWS through OIDC with short-lived roles. All logs flow to a separate Log Archive account protected with S3 Object Lock.

The design follows five principles: least privilege and no static credentials, defence in depth, centralised immutable logging, account isolation to limit blast radius, and automated guardrails.

The STRIDE analysis produced fifteen threats. Three scored the maximum risk rating: leaked or long-lived credentials (T1), unauthorised reading of the customer-export bucket (T8) and secrets in source code (T9). These are exactly the conditions exploited in the incident, which shows the threat model would have pointed to the right priorities had it existed beforehand. The full STRIDE table is in `01-cloud-architecture/threat-model.md`.

Ten major cloud risks were identified, including leaked credentials, over-permissive IAM, misconfigured storage, insufficient logging, insecure CI/CD, weak segmentation, shared-responsibility misunderstandings, insecure IoT and AI components and weak backup readiness.

## 4. Governance and framework alignment
Technical controls are only sustainable when anchored in governance. The mapping matrix links 25 controls to NIST CSF 2.0 functions, ISO/IEC 27001:2022 Annex A concepts and CIS Controls v8.

- **NIST CSF 2.0** provides the structure for the programme: Govern, Identify, Protect, Detect, Respond and Recover. The incident exposed weaknesses mainly in Protect (credential management), Detect (alert routing) and Respond (no practised plan).
- **ISO/IEC 27001** is the path to a formal information security management system: scope, risk assessment, Statement of Applicability, internal audit and management review. The 90-day roadmap begins this work.
- **CIS Controls v8** provides prescriptive safeguards. NimbusPay should target Implementation Group 2, adding selected Group 3 practices for logging, incident response and data protection.

The practical benefit is traceability: each roadmap item can be defended to executives (framework language) and to engineers (specific safeguards).

## 5. Incident analysis
**Summary.** A key for the IAM user `svc-export-batch` was committed to a public repository at 09:12 UTC. AWS sent an exposed-key notice to an unmonitored mailbox at 09:40. At 11:47 the key was used from `198.51.100.23`, followed by discovery calls and a listing of the production customer-export bucket. Between 12:03 and 12:41, 1,284 objects (about 4.6 GB) were downloaded from `203.0.113.77`. At 12:48-12:49 the attacker created `backup-svc-01`, attached AdministratorAccess and generated a new access key. At 13:05 an attempt to stop CloudTrail logging was denied. The analyst noticed the alarm at 14:20, declared an incident at 14:35, deactivated the original key at 14:42 and the attacker's account at 14:55, and escalated to SEV1 at 15:10 after confirming the download.

**Attack path.** Credentials in files → valid cloud account → discovery → data from cloud storage → create account and escalate → attempted log disabling. These map to ATT&CK techniques T1552.001, T1078.004, T1580/T1526, T1530, T1136.003/T1098 and T1562.008.

**Affected assets.** The compromised key, the exports bucket and its contents, the attacker-created user, the production AWS account (admin-level access held for roughly 1.5 hours), the public repository and the developer workstation (under review). RDS, ECS, SageMaker, IoT and DR resources were verified as unaffected.

**Root cause.** Immediate: a long-lived key exposed publicly and used by an unauthorised party. Contributing: no secret scanning, excessive key permissions, no data-event logging, alerts not paged. Underlying: no ownership of credential lifecycle and monitoring, and no incident-response plan.

**Confidence and limits.** The behaviour (rapid use, scripted discovery, bulk download, simple persistence) suggests opportunistic harvesting rather than a targeted attack. Download counts rely on best-effort S3 access logs, so actual volume may be higher; all exported data is treated as disclosed. IP addresses may be proxies and are not evidence of identity.

**Business impact.** Confidential customer data was disclosed, creating notification obligations, potential regulatory attention, reputational harm and contract risk. There was no service outage and no evidence of tampering with production data.

## 6. Response, forensics and recovery
The incident-response plan follows the six phases required: preparation, identification, containment, eradication, recovery and lessons learned. It defines roles, four severity levels with response targets, communication and notification rules and a leaked-credential playbook. In this incident, preparation was the weakest phase; there was no plan, no paged on-call and no pre-provisioned response access.

The evidence-handling plan covers collection in order of volatility, preservation in a dedicated evidence account with Object Lock, integrity through SHA-256 hashing and CloudTrail log-file validation, and documentation through an evidence register and chain-of-custody form. Evidence is limited to what the investigation needs and handled only by authorised staff.

Recovery included rotating dependent secrets, replacing static keys in the batch pipeline with a role, restricting bucket access, removing leaked secrets from the repository history (while treating them as compromised regardless), and 30 days of heightened monitoring. A blameless review five days after closure produced the roadmap actions.

## 7. DevSecOps, AI and IoT
**DevSecOps.** Security is built into each stage: pre-commit hooks and push protection stop secrets; protected branches and reviews govern changes; CI runs SAST, SCA, IaC and container scans; images are signed and only signed images deploy; pipelines authenticate by OIDC with no stored keys; runtime telemetry feeds the backlog. Dependency management uses lock files, SBOMs and patch-time targets (critical within 7 days). Every control is tied to a threat from the model.

**AI-enabled systems.** The fraud model introduces data risks (poisoning, leakage), identity risks (over-privileged ML roles), model-trust risks (tampering, extraction, adversarial inputs, supply chain) and monitoring risks (drift, unobserved abuse). Priorities are to split ML roles, protect training data, sign and register models, and monitor drift and usage.

**IoT devices.** The terminal fleet requires unique device certificates, secure boot and signed firmware updates, mutual TLS, scoped IoT policies, behavioural monitoring through Device Defender and a tested quarantine process. Fleet inventory and firmware visibility are immediate gaps.

## 8. Prioritised roadmap and investment
The 90-day roadmap contains 24 actions in three phases. Phase 1 (days 0-30) removes the conditions of the incident: secret scanning and push protection, key inventory and rotation, paged alerting, logging and GuardDuty, bucket hardening, SCP guardrails, approval and rehearsal of the IR plan, and customer-notification decisions. Phase 2 (days 31-60) builds foundations: SSO with FIDO2, least-privilege review, immutable log archive, keyless CI/CD, secret rotation, scanning gates, detection use cases and forensic readiness. Phase 3 (days 61-90) matures and verifies: immutable backups with a restore test, network controls, AI and IoT hardening, data classification, training, ISMS scoping, an independent test and executive review.

Each item has an owner, an effort estimate (S/M/L), a priority and an expected outcome. Recommended investments, in order of value, are secret-scanning and CI security tooling, 24x7 alert paging or managed detection, FIDO2 keys for administrators, immutable storage for logs and backups, an external penetration test, and training.

**Success measures at day 90:** no static keys in production, push protection on every repository, high-severity alerts triaged within 15 minutes, two completed tabletop exercises, a passed restore test and completion of all P1 actions and at least 80% of P2 actions.

## 9. Professional development
This capstone shows skills across cloud security, governance, incident response, forensics, DevSecOps and AI/IoT. The career section sets out target roles (cloud security analyst, SOC analyst, DFIR analyst, DevSecOps engineer, GRC analyst), a staged certification path starting with Security+ and AWS credentials and moving to AWS Security Specialty, CySA+, ISO 27001 and later CISSP or OSCP, and learning priorities centred on hands-on labs, detection engineering, forensics and communication. Professional ethics, authorisation and responsible disclosure remain core.

# Part II: Key Deliverables

The full set of deliverables (threat model, checklist, mapping matrix, IR plan, IOCs, evidence-handling plan, chain-of-custody template, DevSecOps plan, AI/IoT assessment and career plan) is provided as separate files in this repository; see README.md for the index. The four deliverables most central to the executive story are reproduced here.

## Secure Cloud Architecture

### 1. Design principles
1. **Least privilege and no long-lived credentials**: humans use SSO with MFA; workloads use IAM roles.
2. **Defence in depth**: edge protection, network segmentation, host/container hardening, data encryption.
3. **Everything logged, centrally and immutably**: separate log-archive account.
4. **Multi-account isolation** to limit blast radius.
5. **Automated guardrails**: Service Control Policies (SCPs), AWS Config rules, IaC scanning.

### 2. Account structure (AWS Organizations)
| Account | Purpose |
|---------|---------|
| Management | Billing and Organizations only; no workloads |
| Security / Audit | GuardDuty, Security Hub, IAM Access Analyzer administration |
| Log Archive | Immutable CloudTrail, VPC Flow, Config, ALB logs (S3 Object Lock) |
| Shared Services | CI/CD runners, artifact registry (ECR) |
| Prod | Production workload |
| Non-Prod | Dev/Test with synthetic data only |

### 3. Reference architecture (production)
```mermaid
flowchart TB
    U[Customers / Browsers] --> CF[CloudFront + AWS WAF + Shield]
    CF --> S3W[(S3: static SPA<br/>OAC, private)]
    CF --> ALB[Application Load Balancer<br/>TLS 1.2+]
    subgraph VPC[Prod VPC - 3 tiers, 2 AZs]
      subgraph PUB[Public subnets]
        ALB
        NAT[NAT Gateway]
      end
      subgraph APP[Private app subnets]
        ECS[ECS Fargate services<br/>task roles, no static keys]
      end
      subgraph DATA[Isolated data subnets]
        RDS[(RDS PostgreSQL<br/>KMS encrypted, Multi-AZ)]
      end
      ALB --> ECS --> RDS
      ECS --> VPCE[VPC Endpoints<br/>S3, KMS, Secrets Manager, ECR]
    end
    VPCE --> S3D[(S3: customer exports<br/>SSE-KMS, Block Public Access)]
    VPCE --> SM[Secrets Manager]
    ECS --> SMK[SageMaker fraud endpoint<br/>VPC-only, private]
    IOT[IoT terminals<br/>X.509 device certs] --> IOTC[AWS IoT Core<br/>per-device policies]
    IOTC --> ECS
    subgraph SEC[Security and Log Archive accounts]
      CT[Org CloudTrail]
      GD[GuardDuty]
      SH[Security Hub]
      CFG[AWS Config]
      LA[(Log Archive S3<br/>Object Lock)]
    end
    CT --> LA
    VPC -. flow logs .-> LA
    GD --> SH
    DEV[Engineers] -->|SSO + MFA| IC[IAM Identity Center]
    IC --> VPC
    GH[GitHub Actions] -->|OIDC, short-lived role| ECR[ECR / Deploy]
```

### 4. Key security controls by layer
| Layer | Controls |
|-------|----------|
| Edge | CloudFront, WAF managed rules (OWASP, bot control), rate limiting, Shield |
| Network | 3-tier VPC, security groups referencing groups, NACLs as backstop, no public IPs on workloads, VPC endpoints, flow logs |
| Compute | Fargate (no host patching), minimal signed images, read-only root FS, non-root user, ECR image scanning |
| Identity | SSO + MFA (phishing-resistant for admins), IAM roles for workloads, permission boundaries, SCPs, IAM Access Analyzer |
| Data | KMS keys per data class, TLS everywhere, S3 Block Public Access, bucket policies requiring TLS and VPC endpoint, RDS encryption, cross-region backups |
| Secrets | AWS Secrets Manager with rotation; no secrets in code or env files |
| Logging / monitoring | Org CloudTrail (management + S3 data events), GuardDuty, Security Hub, Config, CloudWatch alarms, SIEM forwarding |
| Resilience | Multi-AZ, automated backups, DR region, tested restores, S3 versioning |

### 5. Major cloud security risks
| # | Risk | Relevance |
|---|------|-----------|
| R1 | Leaked or long-lived credentials | Root cause of the incident |
| R2 | Overly permissive IAM (wildcards) | Enables privilege escalation and persistence |
| R3 | Misconfigured storage | Direct data exposure |
| R4 | Insufficient logging and detection | Slow detection, weak forensics |
| R5 | Insecure CI/CD and supply chain | Pipeline compromise, malicious dependencies |
| R6 | Vulnerable container images | Initial access to workloads |
| R7 | Weak network segmentation | Lateral movement |
| R8 | Misunderstanding shared responsibility | Gaps assumed covered by provider |
| R9 | Insecure IoT/AI components | Device impersonation, model poisoning |
| R10 | Backup and recovery gaps | Failed recovery after destructive attack |

### 6. Shared responsibility
AWS secures the cloud itself (facilities, hypervisor, managed-service internals). NimbusPay secures what it puts in the cloud: IAM, data, configuration, network rules, application code and monitoring.

---

## Incident Timeline (fictional, all times UTC, 2026-09-22)

**Incident ID:** NP-2026-014 | **Final severity:** SEV1 | **Classification:** Credential exposure leading to cloud data exfiltration

Sources: GitHub commit metadata, AWS CloudTrail management events, S3 server access logs, AWS notification email, IAM credential report, CloudWatch alarm history. Times marked *(est.)* are inferred.

| Time (UTC) | Event | Source | Phase |
|-----------|-------|--------|-------|
| 09:12 | Developer A. Verma commits `.env` containing access key for IAM user `svc-export-batch` to a personal repo `export-tools` | GitHub commit log | Exposure |
| 09:14 | Repository pushed; the repo is **public** | GitHub | Exposure |
| 09:40 | AWS sends "exposed access key" notification to the account's registered contact mailbox (shared, unmonitored) | AWS notification email | Missed detection |
| 11:47 | First use of the key from `198.51.100.23`: `GetCallerIdentity` | CloudTrail | Initial access |
| 11:49 | `ListBuckets`, `GetBucketPolicy`, `GetBucketAcl`, `ListAttachedUserPolicies` | CloudTrail | Discovery |
| 11:55 | `ListObjectsV2` on `nimbuspay-prod-customer-exports` | S3 server access logs | Discovery |
| 12:03-12:41 | 1,284 `GetObject` requests (~4.6 GB) from `203.0.113.77` | S3 server access logs | Exfiltration |
| 12:48 | `CreateUser` `backup-svc-01` from `198.51.100.23` | CloudTrail | Persistence |
| 12:49 | `AttachUserPolicy` (AdministratorAccess) and `CreateAccessKey` for `backup-svc-01` | CloudTrail | Persistence / privilege escalation |
| 13:05 | `StopLogging` attempted on the trail using `backup-svc-01`; **denied** (trail managed from management account) | CloudTrail | Defence evasion (failed) |
| 13:20 | Last observed activity; no further calls *(est. attacker paused)* | CloudTrail | n/a |
| 14:20 | Security analyst notices CloudWatch alarm "CreateUser from non-corporate IP" that fired at 12:48 | Alarm history | **Detection (about 1h 32m after alarm, 2h 33m after first misuse)** |
| 14:35 | Incident declared SEV2 (privileged key misuse); IC assigned | IR log | Identification |
| 14:42 | Key for `svc-export-batch` deactivated; explicit-deny policy and session revocation applied | CloudTrail | Containment |
| 14:55 | `backup-svc-01` access key deactivated, user disabled (retained for evidence) | CloudTrail | Containment |
| 15:10 | Server access logs confirm bulk download; escalated to **SEV1**; Legal and CTO notified | IR log | Identification |
| 15:30 | Public repo reported to GitHub and made private; commit history preserved (hash recorded) | IR log | Containment |
| 16:00 | Evidence collection begins: CloudTrail export, S3 logs, IAM credential report, repo snapshot | Forensics log | Evidence |
| 18:30 | Full IAM/resource sweep complete; no other persistence found in any region | Hunt results | Eradication |
| Day +1 | Secrets rotated; roles replace static keys in batch pipeline; bucket restricted via policy | Change records | Eradication / Recovery |
| Day +2 | Customer-notification decision made with Legal | Legal record | Communication |
| Day +5 | Blameless post-incident review held | Meeting record | Lessons learned |

### Key metrics
| Metric | Value |
|--------|-------|
| Exposure to first misuse | ~2 h 35 m (09:12 to 11:47) |
| First misuse to containment | ~2 h 55 m (11:47 to 14:42) |
| Alarm to human response | ~1 h 32 m |
| Exfiltration window | ~38 min |
| Attacker dwell time (observed) | ~1 h 33 m |

### Detection gaps this timeline reveals
1. No secret scanning or push protection.
2. AWS notification went to an unmonitored mailbox.
3. Alarm routed to a shared inbox with no on-call or paging.
4. S3 data events not enabled; reliance on best-effort server access logs.
5. No GuardDuty alerting tied to paging for anomalous S3 access.

---

## Probable Attack Path and Forensic Analysis (fictional)

### Probable attack path
```mermaid
flowchart LR
    A[1. Developer commits .env<br/>to public GitHub repo] --> B[2. Attacker harvests key<br/>via automated repo scanning]
    B --> C[3. Valid cloud account use<br/>GetCallerIdentity from 198.51.100.23]
    C --> D[4. Discovery<br/>ListBuckets, policies, ListObjects]
    D --> E[5. Collection and exfiltration<br/>1,284 GetObject from 203.0.113.77]
    E --> F[6. Persistence<br/>CreateUser + AdministratorAccess + access key]
    F --> G[7. Defence evasion attempt<br/>StopLogging denied]
    G --> H[8. Detection<br/>alarm acted on 1h32m late]
```

### MITRE ATT&CK mapping (cloud / enterprise)
| Step | Tactic | Technique |
|------|--------|-----------|
| 1-2 | Credential Access | T1552.001 Unsecured Credentials: Credentials in Files |
| 3 | Initial Access | T1078.004 Valid Accounts: Cloud Accounts |
| 4 | Discovery | T1580 Cloud Infrastructure Discovery; T1526 Cloud Service Discovery |
| 5 | Collection / Exfiltration | T1530 Data from Cloud Storage |
| 6 | Persistence / Privilege Escalation | T1136.003 Create Account: Cloud Account; T1098 Account Manipulation |
| 7 | Defense Evasion | T1562.008 Impair Defenses: Disable or Modify Cloud Logs |

### Root cause analysis
| Level | Finding |
|-------|---------|
| Immediate cause | Long-lived access key exposed in a public repository and used by an unauthorised party |
| Contributing technical causes | No secret scanning or push protection; static keys used for a batch job; the key's policy allowed broad S3 read on production export bucket and some IAM read; no S3 data-event logging; alerts not paged |
| Contributing process causes | No policy against personal-repo use for company code; AWS notices to an unmonitored mailbox; no on-call rota; IR plan absent |
| Root cause | Absence of preventive and detective controls around credential lifecycle, combined with weak monitoring ownership |

### Forensic analysis notes
1. **Authenticity of attribution:** the observed IPs are unverified and may be proxies or VPN endpoints; attribution to a person or group is out of scope.
2. **Scope confidence:** download count is derived from S3 server access logs, which are best-effort; true volume could be higher. Mitigated by enabling S3 data events (roadmap item).
3. **Integrity of evidence:** CloudTrail log-file validation passed; log archive hashes recorded.
4. **Persistence sweep:** IAM users, roles, trust policies, access keys, OIDC providers, Lambda functions and EventBridge rules were reviewed in all enabled regions; only `backup-svc-01` was unauthorised.
5. **Data exposure:** exported files were CSV with business and bank-reference fields; classified as confidential. Treat all as disclosed.
6. **Open questions:** was the developer workstation itself compromised; were other secrets in the repo history; were any forks created before takedown.

### Analyst conclusion
High confidence that the incident was opportunistic credential harvesting rather than a targeted intrusion: rapid use after exposure, scripted discovery, bulk download, then a basic persistence attempt. The impact was serious because of excessive permissions and slow detection, not attacker sophistication.

---

## 90-Day Prioritised Security Improvement Roadmap

Priority: **P1** critical (do first), **P2** high, **P3** medium. Effort: S (≤3 days), M (≤2 weeks), L (≤6 weeks). Every item traces to an incident finding or checklist gap.

### Phase 1: Days 0-30 "Stop the bleeding"
| # | Action | Owner | Effort | Priority | Expected outcome | Traces to |
|---|--------|-------|--------|----------|------------------|-----------|
| 1 | Enable GitHub secret scanning and push protection org-wide; add gitleaks pre-commit and CI check | DevOps Lead | S | P1 | Secrets blocked before reaching a remote | Root cause, T9 |
| 2 | Inventory and rotate all IAM access keys; disable unused; begin replacing with roles | Cloud Engineer | M | P1 | No unmanaged static keys in prod | T1, checklist 1.4, 1.7 |
| 3 | Route security alarms and AWS notices to paged on-call; create monitored security mailbox | Head of Security | S | P1 | Alarm-to-response under 15 minutes | Detection gap |
| 4 | Enable org-wide CloudTrail with S3 data events on sensitive buckets, GuardDuty and Security Hub | Cloud Engineer | M | P1 | Complete visibility of data access | 4.1, 4.2, 5.1 |
| 5 | Apply S3 Block Public Access and restrictive bucket policy (VPC endpoint/roles) on exports bucket; lifecycle expiry on exports | Cloud Engineer | S | P1 | Reduced data exposure | T8 |
| 6 | Approve IR plan v1.0 and run first tabletop | Head of Security | S | P1 | Defined roles, tested process | 8.1, 8.5 |
| 7 | Add SCPs: deny CloudTrail changes, deny IAM user creation outside approved roles | Cloud Engineer | S | P1 | Block persistence and log tampering | T5, T13 |
| 8 | Complete customer-notification decisions with Legal | Legal / CISO | S | P1 | Compliance with obligations | Incident impact |

### Phase 2: Days 31-60 "Build the foundations"
| # | Action | Owner | Effort | Priority | Expected outcome | Traces to |
|---|--------|-------|--------|----------|------------------|-----------|
| 9 | Move human access to SSO with MFA; FIDO2 keys for admins | IT Lead | M | P1 | Strong authentication | T2 |
| 10 | Least-privilege IAM review; permission boundaries; IAM Access Analyzer findings cleared | Cloud Engineer | L | P2 | Reduced blast radius | T13, R2 |
| 11 | Centralise logs in Log Archive account with Object Lock; 12-month retention | Cloud Engineer | M | P2 | Tamper-resistant evidence | 4.4, 4.5 |
| 12 | GitHub Actions to OIDC roles; remove stored keys from pipelines | DevOps Lead | M | P2 | Keyless CI/CD | T15 |
| 13 | Secrets to Secrets Manager with rotation | DevOps Lead | M | P2 | Managed secret lifecycle | 6.1, 6.2 |
| 14 | Add SAST, SCA, IaC and container scanning gates to CI | DevOps Lead | L | P2 | Fewer vulnerabilities shipped | T4, R6 |
| 15 | Build detection use cases (new-IP key use, bulk S3 download, IAM changes) | Security Analyst | M | P2 | Faster detection | IOC-derived |
| 16 | Create evidence account and finalise forensic runbooks | Forensics Lead | M | P2 | Defensible evidence handling | Plan 06 |

### Phase 3: Days 61-90 "Mature and verify"
| # | Action | Owner | Effort | Priority | Expected outcome | Traces to |
|---|--------|-------|--------|----------|------------------|-----------|
| 17 | Cross-region, cross-account immutable backups; first restore test | Cloud Engineer | M | P2 | Proven recoverability | R10 |
| 18 | VPC endpoints, egress controls, WAF tuning | Network Engineer | M | P2 | Reduced lateral movement and exfil paths | R7 |
| 19 | AI/IoT: split ML roles, enable Device Defender, fleet inventory, signed model/firmware | ML Lead / IoT Lead | L | P2 | Reduced AI/IoT risk | Plan 08 |
| 20 | Data classification and Macie scanning of sensitive buckets | Data Owner | M | P3 | Know where sensitive data lives | R3 |
| 21 | Security awareness and secure-coding training; security champions | Security Lead | S | P3 | Fewer human-error incidents | CIS 14 |
| 22 | Start ISMS scoping, risk register, Statement of Applicability draft | CISO | M | P3 | Governance roadmap for ISO 27001 | Mapping |
| 23 | Independent review or authorised penetration test of prod | CISO | M | P3 | External assurance | DevSecOps |
| 24 | Executive review of metrics and 90-day results | CISO | S | P3 | Sustained funding and focus | Governance |

### Resourcing summary
| Phase | Items | Estimated effort (person-days) | Indicative cost (planning figure) |
|-------|-------|-------------------------------|-----------------------------------|
| 0-30 | 8 | ~35 | Mostly tooling already licensed; low |
| 31-60 | 8 | ~70 | Medium (hardware keys, scanning tools) |
| 61-90 | 8 | ~60 | Medium (backup storage, external test) |

### Success measures at Day 90
- 100% of repos with push protection; 0 static keys in production workloads.
- Mean time to detect high-severity cloud alerts under 15 minutes.
- Tabletop completed at least twice; first restore test passed.
- All P1 and 80% of P2 actions complete.

---

# Part III: Conclusion and References

## Conclusion
The incident at NimbusPay was serious but preventable. Its causes were basic and common: credentials that lived too long, permissions that were too broad, and alerts without owners. The response in this capstone shows how a layered programme addresses those causes: a secure architecture that removes static keys and limits blast radius, governance mapped to recognised frameworks, a practised incident-response capability, forensic readiness, security embedded in the development pipeline, and attention to AI and IoT risks.

The 90-day roadmap is intentionally front-loaded. The first thirty days remove the exact conditions that enabled this incident, the next thirty build durable foundations, and the final thirty verify and mature the programme. Measured outcomes such as zero static keys, push protection on every repository and sub-15-minute alert triage give leadership evidence that the investment is working.

## Limitations
This is a fictional scenario built for learning. Real incidents would require validated legal advice on notification, deeper log analysis, and organisation-specific risk decisions. Framework mappings are at concept level and should be checked against the current published standards.

## References
- NIST Cybersecurity Framework 2.0 (NIST, 2024)
- NIST SP 800-61 Rev. 2/3, Computer Security Incident Handling Guide
- NIST SP 800-86, Guide to Integrating Forensic Techniques into Incident Response
- ISO/IEC 27001:2022, Information security management systems
- ISO/IEC 27035, Information security incident management
- CIS Controls v8 (Center for Internet Security)
- MITRE ATT&CK for Enterprise and Cloud matrices
- AWS Well-Architected Framework, Security Pillar; AWS Security Incident Response Guide
- OWASP Top 10; OWASP DevSecOps Guideline
- OWASP Machine Learning Security Top 10; NIST AI Risk Management Framework
- AWS IoT security best practices
