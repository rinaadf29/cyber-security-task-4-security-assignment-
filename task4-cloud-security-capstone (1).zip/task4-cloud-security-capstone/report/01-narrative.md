# Part I: Report

## 1. Executive summary
NimbusPay, a fictional fintech software company with about 150 staff, is moving its critical services to Amazon Web Services while building a more mature security and governance programme. During this transition a security incident (NP-2026-014) occurred. A developer accidentally committed an AWS access key to a public GitHub repository. About two and a half hours later the key was used by an unknown party to explore the cloud account, download roughly 4.6 GB of customer export data belonging to around 62 customers, and create a new administrator account to keep access.

The attacker's actions were not sophisticated. The damage was made possible by long-lived credentials, permissions broader than the task required, missing secret scanning, and alerts that nobody was paged to act on. An alarm for the suspicious account creation fired at 12:48 UTC but was not seen until 14:20 UTC. Containment was complete at 14:42 UTC for the original key and 14:55 UTC for the attacker-created account.

This report presents a complete response and improvement programme: a secure target architecture and threat model, a cloud security checklist, mappings to NIST CSF 2.0, ISO/IEC 27001 and CIS Controls, an incident-response plan, a timeline and forensic analysis, an evidence-handling plan, a DevSecOps plan, an AI and IoT assessment, and a prioritised 90-day roadmap with owners and effort estimates.

**The most important recommendations are:**
1. Eliminate long-lived keys and block secrets from reaching source control.
2. Route security alerts to a paged, monitored on-call process.
3. Enforce least privilege and guardrails (SCPs) across all AWS accounts.
4. Centralise immutable logging and enable data-event visibility on sensitive storage.
5. Approve and rehearse the incident-response plan.

Delivering the 90-day roadmap would remove the conditions that allowed this incident and measurably shorten detection and response times.

## 2. Introduction, scope and method

### 2.1 Objective
To act as lead security analyst: design the security programme, analyse the incident and recommend prioritised improvements that leaders can approve and fund.

### 2.2 Scope
The scope covers NimbusPay's representative production workload on AWS (web front end, containerised services, PostgreSQL database, S3 storage, an ML fraud model and an IoT terminal fleet), its CI/CD pipeline on GitHub, and the people and processes around them.

### 2.3 Method
1. **Model the workload** and its trust boundaries.
2. **Identify threats** using STRIDE and rate them by likelihood and impact.
3. **Assess control gaps** with a cloud security checklist (52 controls; 5 fully in place, 16 partial, 31 absent).
4. **Map controls to frameworks** to link technical work to governance expectations.
5. **Reconstruct the incident** from logs and metadata into a timeline, indicators of compromise and an attack path, mapped to MITRE ATT&CK.
6. **Define response, forensic and DevSecOps processes** that would have prevented or shortened the incident.
7. **Prioritise remediation** into a 90-day roadmap with owners, effort and outcomes.

### 2.4 Ethics and safety
The work is entirely fictional. No scanning, exploitation, credential attack, phishing, malware or data collection was carried out against any real system. Evidence handling follows a minimum-necessary principle.

## 3. Secure cloud architecture and threat model
The target design uses a multi-account AWS organisation (management, security, log archive, shared services, production, non-production). Production uses a three-tier VPC: public subnets hold only the load balancer and NAT; application containers run on Fargate in private subnets using task roles instead of keys; the database sits in isolated subnets with KMS encryption. Traffic to S3, KMS, Secrets Manager and ECR flows through VPC endpoints. CloudFront with AWS WAF protects the edge. People sign in through IAM Identity Center with MFA; GitHub Actions authenticates to AWS through OIDC with short-lived roles. All logs flow to a separate Log Archive account protected with S3 Object Lock.

The design follows five principles: least privilege and no static credentials, defence in depth, centralised immutable logging, account isolation to limit blast radius, and automated guardrails.

The STRIDE analysis produced fifteen threats. Three scored the maximum risk rating: leaked or long-lived credentials (T1), unauthorised reading of the customer-export bucket (T8) and secrets in source code (T9). These are exactly the conditions exploited in the incident, which shows the threat model would have pointed to the right priorities had it existed beforehand. The full STRIDE table is in `01-cloud-architecture/threat-model.md`.

Ten major cloud risks were identified, including leaked credentials, over-permissive IAM, misconfigured storage, insufficient logging, insecure CI/CD, weak segmentation, shared-responsibility misunderstandings, insecure IoT and AI components and weak backup readiness.

## 4. Governance and framework alignment
Technical controls are only sustainable when anchored in governance. The mapping matrix links 25 controls to NIST CSF 2.0 functions, ISO/IEC 27001:2022 Annex A concepts and CIS Controls v8.

- **NIST CSF 2.0** provides the structure for the programme: Govern, Identify, Protect, Detect, Respond and Recover. The incident exposed weaknesses mainly in Protect (credential management), Detect (alert routing) and Respond (no practised plan).
- **ISO/IEC 27001** is the path to a formal information security management system: scope, risk assessment, Statement of Applicability, internal audit and management review. The 90-day roadmap begins this work.
- **CIS Controls v8** provides prescriptive safeguards. NimbusPay should target Implementation Group 2, adding selected Group 3 practices for logging, incident response and data protection.

The practical benefit is traceability: each roadmap item can be defended to executives (framework language) and to engineers (specific safeguards).

## 5. Incident analysis
**Summary.** A key for the IAM user `svc-export-batch` was committed to a public repository at 09:12 UTC. AWS sent an exposed-key notice to an unmonitored mailbox at 09:40. At 11:47 the key was used from `198.51.100.23`, followed by discovery calls and a listing of the production customer-export bucket. Between 12:03 and 12:41, 1,284 objects (about 4.6 GB) were downloaded from `203.0.113.77`. At 12:48-12:49 the attacker created `backup-svc-01`, attached AdministratorAccess and generated a new access key. At 13:05 an attempt to stop CloudTrail logging was denied. The analyst noticed the alarm at 14:20, declared an incident at 14:35, deactivated the original key at 14:42 and the attacker's account at 14:55, and escalated to SEV1 at 15:10 after confirming the download.

**Attack path.** Credentials in files → valid cloud account → discovery → data from cloud storage → create account and escalate → attempted log disabling. These map to ATT&CK techniques T1552.001, T1078.004, T1580/T1526, T1530, T1136.003/T1098 and T1562.008.

**Affected assets.** The compromised key, the exports bucket and its contents, the attacker-created user, the production AWS account (admin-level access held for roughly 1.5 hours), the public repository and the developer workstation (under review). RDS, ECS, SageMaker, IoT and DR resources were verified as unaffected.

**Root cause.** Immediate: a long-lived key exposed publicly and used by an unauthorised party. Contributing: no secret scanning, excessive key permissions, no data-event logging, alerts not paged. Underlying: no ownership of credential lifecycle and monitoring, and no incident-response plan.

**Confidence and limits.** The behaviour (rapid use, scripted discovery, bulk download, simple persistence) suggests opportunistic harvesting rather than a targeted attack. Download counts rely on best-effort S3 access logs, so actual volume may be higher; all exported data is treated as disclosed. IP addresses may be proxies and are not evidence of identity.

**Business impact.** Confidential customer data was disclosed, creating notification obligations, potential regulatory attention, reputational harm and contract risk. There was no service outage and no evidence of tampering with production data.

## 6. Response, forensics and recovery
The incident-response plan follows the six phases required: preparation, identification, containment, eradication, recovery and lessons learned. It defines roles, four severity levels with response targets, communication and notification rules and a leaked-credential playbook. In this incident, preparation was the weakest phase; there was no plan, no paged on-call and no pre-provisioned response access.

The evidence-handling plan covers collection in order of volatility, preservation in a dedicated evidence account with Object Lock, integrity through SHA-256 hashing and CloudTrail log-file validation, and documentation through an evidence register and chain-of-custody form. Evidence is limited to what the investigation needs and handled only by authorised staff.

Recovery included rotating dependent secrets, replacing static keys in the batch pipeline with a role, restricting bucket access, removing leaked secrets from the repository history (while treating them as compromised regardless), and 30 days of heightened monitoring. A blameless review five days after closure produced the roadmap actions.

## 7. DevSecOps, AI and IoT
**DevSecOps.** Security is built into each stage: pre-commit hooks and push protection stop secrets; protected branches and reviews govern changes; CI runs SAST, SCA, IaC and container scans; images are signed and only signed images deploy; pipelines authenticate by OIDC with no stored keys; runtime telemetry feeds the backlog. Dependency management uses lock files, SBOMs and patch-time targets (critical within 7 days). Every control is tied to a threat from the model.

**AI-enabled systems.** The fraud model introduces data risks (poisoning, leakage), identity risks (over-privileged ML roles), model-trust risks (tampering, extraction, adversarial inputs, supply chain) and monitoring risks (drift, unobserved abuse). Priorities are to split ML roles, protect training data, sign and register models, and monitor drift and usage.

**IoT devices.** The terminal fleet requires unique device certificates, secure boot and signed firmware updates, mutual TLS, scoped IoT policies, behavioural monitoring through Device Defender and a tested quarantine process. Fleet inventory and firmware visibility are immediate gaps.

## 8. Prioritised roadmap and investment
The 90-day roadmap contains 24 actions in three phases. Phase 1 (days 0-30) removes the conditions of the incident: secret scanning and push protection, key inventory and rotation, paged alerting, logging and GuardDuty, bucket hardening, SCP guardrails, approval and rehearsal of the IR plan, and customer-notification decisions. Phase 2 (days 31-60) builds foundations: SSO with FIDO2, least-privilege review, immutable log archive, keyless CI/CD, secret rotation, scanning gates, detection use cases and forensic readiness. Phase 3 (days 61-90) matures and verifies: immutable backups with a restore test, network controls, AI and IoT hardening, data classification, training, ISMS scoping, an independent test and executive review.

Each item has an owner, an effort estimate (S/M/L), a priority and an expected outcome. Recommended investments, in order of value, are secret-scanning and CI security tooling, 24x7 alert paging or managed detection, FIDO2 keys for administrators, immutable storage for logs and backups, an external penetration test, and training.

**Success measures at day 90:** no static keys in production, push protection on every repository, high-severity alerts triaged within 15 minutes, two completed tabletop exercises, a passed restore test and completion of all P1 actions and at least 80% of P2 actions.

## 9. Professional development
This capstone shows skills across cloud security, governance, incident response, forensics, DevSecOps and AI/IoT. The career section sets out target roles (cloud security analyst, SOC analyst, DFIR analyst, DevSecOps engineer, GRC analyst), a staged certification path starting with Security+ and AWS credentials and moving to AWS Security Specialty, CySA+, ISO 27001 and later CISSP or OSCP, and learning priorities centred on hands-on labs, detection engineering, forensics and communication. Professional ethics, authorisation and responsible disclosure remain core.
