#!/usr/bin/env bash
# Rebuilds report/capstone-report.md from narrative sections plus the project artifacts.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT=report/capstone-report.md
demote() { sed -E 's/^(#{1,5}) /\1# /' "$1"; }   # push headings down one level
{
  cat report/00-front-matter.md
  cat report/01-narrative.md
  echo; echo "# Part II: Key Deliverables"; echo; echo "The full set of deliverables (threat model, checklist, mapping matrix, IR plan, IOCs, evidence-handling plan, chain-of-custody template, DevSecOps plan, AI/IoT assessment and career plan) is provided as separate files in this repository; see README.md for the index. The four deliverables most central to the executive story are reproduced here."; echo
  for f in \
    01-cloud-architecture/architecture.md \
    05-incident-analysis/timeline.md \
    05-incident-analysis/attack-path.md \
    09-roadmap-90-days.md ; do
    demote "$f"; echo; echo "---"; echo
  done
  cat report/02-conclusion.md
} > "$OUT"
echo "Built $OUT ($(wc -w < "$OUT") words)"
