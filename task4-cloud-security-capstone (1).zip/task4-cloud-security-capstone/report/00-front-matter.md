# Cloud Security, Incident Response and Cybersecurity Capstone Report

**Organisation (fictional):** NimbusPay
**Prepared by:** Lead Security Analyst (Rinad)
**Course:** Cybersecurity, Task 4 (Modules 13-15)
**Classification:** Confidential, academic exercise only

> All names, IP addresses, account IDs, data volumes and dates in this report are fictional. No real system was scanned, tested or attacked, and no real data was collected.

## Table of contents
**Part I: Report**
1. Executive summary
2. Introduction, scope and method
3. Secure cloud architecture and threat model
4. Governance and framework alignment
5. Incident analysis
6. Response, forensics and recovery
7. DevSecOps, AI and IoT
8. Prioritised roadmap and investment
9. Professional development

**Part II: Key deliverables** (reference architecture, incident timeline, attack path, 90-day roadmap; remaining deliverables are separate files in the repository)

**Part III: Conclusion and references**

---
