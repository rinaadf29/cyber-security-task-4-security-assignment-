# Part III: Conclusion and References

## Conclusion
The incident at NimbusPay was serious but preventable. Its causes were basic and common: credentials that lived too long, permissions that were too broad, and alerts without owners. The response in this capstone shows how a layered programme addresses those causes: a secure architecture that removes static keys and limits blast radius, governance mapped to recognised frameworks, a practised incident-response capability, forensic readiness, security embedded in the development pipeline, and attention to AI and IoT risks.

The 90-day roadmap is intentionally front-loaded. The first thirty days remove the exact conditions that enabled this incident, the next thirty build durable foundations, and the final thirty verify and mature the programme. Measured outcomes such as zero static keys, push protection on every repository and sub-15-minute alert triage give leadership evidence that the investment is working.

## Limitations
This is a fictional scenario built for learning. Real incidents would require validated legal advice on notification, deeper log analysis, and organisation-specific risk decisions. Framework mappings are at concept level and should be checked against the current published standards.

## References
- NIST Cybersecurity Framework 2.0 (NIST, 2024)
- NIST SP 800-61 Rev. 2/3, Computer Security Incident Handling Guide
- NIST SP 800-86, Guide to Integrating Forensic Techniques into Incident Response
- ISO/IEC 27001:2022, Information security management systems
- ISO/IEC 27035, Information security incident management
- CIS Controls v8 (Center for Internet Security)
- MITRE ATT&CK for Enterprise and Cloud matrices
- AWS Well-Architected Framework, Security Pillar; AWS Security Incident Response Guide
- OWASP Top 10; OWASP DevSecOps Guideline
- OWASP Machine Learning Security Top 10; NIST AI Risk Management Framework
- AWS IoT security best practices
