# Threat Model (STRIDE)

## Scope and assets
In scope: the production workload in `architecture.md`. Crown jewels: customer export data, RDS transaction data, IAM/admin credentials, signing keys, fraud-model artifacts, log integrity.

## Trust boundaries
1. Internet ↔ CloudFront/WAF
2. Public subnets ↔ private app subnets
3. App subnets ↔ data subnets
4. Workload account ↔ Security/Log Archive accounts
5. Developer workstation / GitHub ↔ AWS (CI/CD and SSO)
6. IoT device ↔ IoT Core

## Data-flow summary
Browser → CloudFront/WAF → ALB → ECS service → RDS / S3 (via VPC endpoints) → SageMaker. Devices → IoT Core → ECS. Engineers → SSO → AWS console/CLI. GitHub Actions → OIDC role → ECR/ECS.

## STRIDE analysis
| ID | Category | Threat | Component | Likelihood | Impact | Mitigation |
|----|----------|--------|-----------|-----------|--------|-----------|
| T1 | Spoofing | Stolen/leaked IAM access key used by attacker | IAM, GitHub | High | High | No long-lived keys, SSO, secret scanning, GuardDuty anomaly alerts |
| T2 | Spoofing | Phished engineer credentials | Identity | Medium | High | Phishing-resistant MFA (FIDO2) for admins, conditional access |
| T3 | Spoofing | Rogue IoT device impersonates a terminal | IoT Core | Medium | Medium | Unique X.509 certs, per-device policy, revocation |
| T4 | Tampering | Modified container image or dependency | CI/CD, ECR | Medium | High | Image signing, SBOM, pinned dependencies, SCA scans |
| T5 | Tampering | Alteration of CloudTrail logs | Logging | Low | High | Org trail, log-file validation, Object Lock, separate account |
| T6 | Tampering | Poisoned training data for fraud model | SageMaker | Low | High | Data provenance, access control, drift monitoring |
| T7 | Repudiation | No proof of who performed an admin action | IAM | Medium | Medium | Named SSO identities, CloudTrail, session tagging |
| T8 | Info disclosure | Customer-export bucket read by unauthorised principal | S3 | High | High | Least privilege, Block Public Access, VPC-endpoint-only policy, data-event logging, Macie |
| T9 | Info disclosure | Secrets in code/env files | Source control | High | High | Secrets Manager, pre-commit and CI secret scanning |
| T10 | Info disclosure | Unencrypted data in transit/at rest | All | Low | High | TLS 1.2+, KMS encryption by default |
| T11 | DoS | Layer 7 flood on API | ALB/ECS | Medium | Medium | WAF rate limits, Shield, autoscaling |
| T12 | DoS | Resource-exhaustion via crafted model queries | SageMaker | Low | Medium | Throttling, quotas, input validation |
| T13 | Elevation of privilege | IAM privilege escalation (`iam:*`, `PassRole`) | IAM | Medium | High | Permission boundaries, SCPs, Access Analyzer, no wildcard policies |
| T14 | Elevation of privilege | Container escape / over-privileged task role | ECS | Low | High | Fargate isolation, scoped task roles, non-root containers |
| T15 | Elevation of privilege | Pipeline compromise yields deploy rights | GitHub Actions | Medium | High | OIDC with branch-scoped trust, protected branches, required reviews |

## Risk rating method
Risk = Likelihood × Impact on a 3-level scale (Low=1, Medium=2, High=3). Scores 6-9 are treated as priority risks and drive the 90-day roadmap.

## Top priority threats
T1, T8, T9 (score 9), then T2, T4, T13, T15 (score 6). These map directly to the incident analysed in `05-incident-analysis/`.
