# Secure Cloud Architecture

## 1. Design principles
1. **Least privilege and no long-lived credentials**: humans use SSO with MFA; workloads use IAM roles.
2. **Defence in depth**: edge protection, network segmentation, host/container hardening, data encryption.
3. **Everything logged, centrally and immutably**: separate log-archive account.
4. **Multi-account isolation** to limit blast radius.
5. **Automated guardrails**: Service Control Policies (SCPs), AWS Config rules, IaC scanning.

## 2. Account structure (AWS Organizations)
| Account | Purpose |
|---------|---------|
| Management | Billing and Organizations only; no workloads |
| Security / Audit | GuardDuty, Security Hub, IAM Access Analyzer administration |
| Log Archive | Immutable CloudTrail, VPC Flow, Config, ALB logs (S3 Object Lock) |
| Shared Services | CI/CD runners, artifact registry (ECR) |
| Prod | Production workload |
| Non-Prod | Dev/Test with synthetic data only |

## 3. Reference architecture (production)
```mermaid
flowchart TB
    U[Customers / Browsers] --> CF[CloudFront + AWS WAF + Shield]
    CF --> S3W[(S3: static SPA<br/>OAC, private)]
    CF --> ALB[Application Load Balancer<br/>TLS 1.2+]
    subgraph VPC[Prod VPC - 3 tiers, 2 AZs]
      subgraph PUB[Public subnets]
        ALB
        NAT[NAT Gateway]
      end
      subgraph APP[Private app subnets]
        ECS[ECS Fargate services<br/>task roles, no static keys]
      end
      subgraph DATA[Isolated data subnets]
        RDS[(RDS PostgreSQL<br/>KMS encrypted, Multi-AZ)]
      end
      ALB --> ECS --> RDS
      ECS --> VPCE[VPC Endpoints<br/>S3, KMS, Secrets Manager, ECR]
    end
    VPCE --> S3D[(S3: customer exports<br/>SSE-KMS, Block Public Access)]
    VPCE --> SM[Secrets Manager]
    ECS --> SMK[SageMaker fraud endpoint<br/>VPC-only, private]
    IOT[IoT terminals<br/>X.509 device certs] --> IOTC[AWS IoT Core<br/>per-device policies]
    IOTC --> ECS
    subgraph SEC[Security and Log Archive accounts]
      CT[Org CloudTrail]
      GD[GuardDuty]
      SH[Security Hub]
      CFG[AWS Config]
      LA[(Log Archive S3<br/>Object Lock)]
    end
    CT --> LA
    VPC -. flow logs .-> LA
    GD --> SH
    DEV[Engineers] -->|SSO + MFA| IC[IAM Identity Center]
    IC --> VPC
    GH[GitHub Actions] -->|OIDC, short-lived role| ECR[ECR / Deploy]
```

## 4. Key security controls by layer
| Layer | Controls |
|-------|----------|
| Edge | CloudFront, WAF managed rules (OWASP, bot control), rate limiting, Shield |
| Network | 3-tier VPC, security groups referencing groups, NACLs as backstop, no public IPs on workloads, VPC endpoints, flow logs |
| Compute | Fargate (no host patching), minimal signed images, read-only root FS, non-root user, ECR image scanning |
| Identity | SSO + MFA (phishing-resistant for admins), IAM roles for workloads, permission boundaries, SCPs, IAM Access Analyzer |
| Data | KMS keys per data class, TLS everywhere, S3 Block Public Access, bucket policies requiring TLS and VPC endpoint, RDS encryption, cross-region backups |
| Secrets | AWS Secrets Manager with rotation; no secrets in code or env files |
| Logging / monitoring | Org CloudTrail (management + S3 data events), GuardDuty, Security Hub, Config, CloudWatch alarms, SIEM forwarding |
| Resilience | Multi-AZ, automated backups, DR region, tested restores, S3 versioning |

## 5. Major cloud security risks
| # | Risk | Relevance |
|---|------|-----------|
| R1 | Leaked or long-lived credentials | Root cause of the incident |
| R2 | Overly permissive IAM (wildcards) | Enables privilege escalation and persistence |
| R3 | Misconfigured storage | Direct data exposure |
| R4 | Insufficient logging and detection | Slow detection, weak forensics |
| R5 | Insecure CI/CD and supply chain | Pipeline compromise, malicious dependencies |
| R6 | Vulnerable container images | Initial access to workloads |
| R7 | Weak network segmentation | Lateral movement |
| R8 | Misunderstanding shared responsibility | Gaps assumed covered by provider |
| R9 | Insecure IoT/AI components | Device impersonation, model poisoning |
| R10 | Backup and recovery gaps | Failed recovery after destructive attack |

## 6. Shared responsibility
AWS secures the cloud itself (facilities, hypervisor, managed-service internals). NimbusPay secures what it puts in the cloud: IAM, data, configuration, network rules, application code and monitoring.
