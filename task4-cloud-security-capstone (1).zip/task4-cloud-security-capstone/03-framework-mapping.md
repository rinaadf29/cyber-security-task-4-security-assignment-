# Framework / Control Mapping Matrix

Maps selected NimbusPay controls to **NIST CSF 2.0**, **ISO/IEC 27001:2022 (Annex A concepts)** and **CIS Controls v8**. Mappings are at concept level; confirm exact clause numbers against the current published standards before formal use.

## NIST CSF 2.0 functions used
GOVERN (GV), IDENTIFY (ID), PROTECT (PR), DETECT (DE), RESPOND (RS), RECOVER (RC).

## Mapping matrix
| # | NimbusPay control | NIST CSF 2.0 | ISO/IEC 27001:2022 concept (Annex A) | CIS Controls v8 | Addresses |
|---|-------------------|--------------|--------------------------------------|-----------------|-----------|
| 1 | Cloud security policy and risk ownership | GV.PO, GV.RR | 5.1 Policies, 5.2 Roles and responsibilities | CIS 1 (inventory) governance foundation | Governance gap |
| 2 | Asset and data inventory/classification | ID.AM | 5.9 Inventory of assets, 5.12 Classification of information | CIS 1, CIS 3 (Data protection) | Unknown data exposure |
| 3 | Risk assessment and threat modelling | ID.RA | Clause 6.1.2 Risk assessment, 5.7 Threat intelligence | CIS 7 (Vulnerability mgmt) | R1-R10 |
| 4 | SSO with MFA, phishing-resistant for admins | PR.AA | 5.15 Access control, 5.17 Authentication information, 8.5 Secure authentication | CIS 5 (Account mgmt), CIS 6 (Access control mgmt) | T2 |
| 5 | Eliminate long-lived keys; use roles; rotate | PR.AA | 5.18 Access rights, 8.2 Privileged access rights | CIS 5, CIS 6 | T1 (root cause) |
| 6 | Least privilege, SCPs, permission boundaries | PR.AA | 5.15, 8.2 | CIS 6 | T13 |
| 7 | Encryption at rest and in transit (KMS, TLS) | PR.DS | 8.24 Use of cryptography | CIS 3 | T10 |
| 8 | S3 Block Public Access, restricted bucket policies | PR.DS, PR.PS | 8.3 Information access restriction, 8.9 Configuration management | CIS 3, CIS 4 (Secure configuration) | T8 |
| 9 | Secrets Manager, secret scanning | PR.DS, PR.PS | 8.4 Access to source code, 5.17 | CIS 3, CIS 16 (App software security) | T9 |
| 10 | Network segmentation, VPC endpoints, security groups | PR.IR | 8.20 Network security, 8.22 Segregation of networks | CIS 12 (Network infrastructure mgmt), CIS 13 (Network monitoring) | T14, R7 |
| 11 | Hardened images, ECR scanning, patching | PR.PS | 8.8 Technical vulnerability mgmt, 8.9 | CIS 4, CIS 7 | R6 |
| 12 | Secure SDLC, SAST/SCA/IaC scanning | PR.PS, ID.RA | 8.25 Secure development lifecycle, 8.28 Secure coding, 8.29 Security testing | CIS 16 | T4, T15 |
| 13 | Centralised immutable logging | DE.CM, PR.PS | 8.15 Logging, 8.17 Clock synchronisation | CIS 8 (Audit log mgmt) | T5, R4 |
| 14 | GuardDuty, Security Hub, alerting | DE.CM, DE.AE | 8.16 Monitoring activities | CIS 8, CIS 13 | Detection delay |
| 15 | Incident-response plan and playbooks | RS.MA, RS.AN | 5.24 Incident management planning, 5.26 Response | CIS 17 (Incident response mgmt) | Response gap |
| 16 | Event assessment and incident reporting | DE.AE, RS.CO | 5.25 Assessment of events, 6.8 Event reporting | CIS 17 | Detection to response |
| 17 | Evidence handling and chain of custody | RS.AN | 5.28 Collection of evidence | CIS 17 | Forensic soundness |
| 18 | Containment, eradication and recovery actions | RS.MI, RC.RP | 5.26, 5.29 Security during disruption | CIS 17, CIS 11 (Data recovery) | Impact reduction |
| 19 | Backups, immutable copies, restore tests | PR.DS, RC.RP | 8.13 Information backup, 5.30 ICT readiness for business continuity | CIS 11 | R10 |
| 20 | Security awareness and secure-coding training | PR.AT | 6.3 Awareness, education and training | CIS 14 (Security awareness) | Human error |
| 21 | Supplier and third-party risk (AWS, SaaS, GitHub) | GV.SC | 5.19-5.23 Supplier relationships, cloud services | CIS 15 (Service provider mgmt) | R8 |
| 22 | IoT device identity and firmware integrity | PR.AA, PR.PS | 8.9, 8.24 | CIS 1, CIS 4 | T3 |
| 23 | AI/ML data, model and access controls | PR.DS, ID.RA | 5.12, 8.3, 8.28 | CIS 3, CIS 16 | T6, T12 |
| 24 | Lessons learned and continuous improvement | ID.IM, GV.OC | Clause 10 Improvement, 5.27 Learning from incidents | CIS 17 | Recurrence |
| 25 | Internal audit and management review | GV.OV | Clause 9 Performance evaluation | All (assessment) | Assurance |

## Coverage view by framework area
| NIST CSF function | Controls (row #) |
|-------------------|------------------|
| GOVERN | 1, 21, 24, 25 |
| IDENTIFY | 2, 3 |
| PROTECT | 4-12, 19, 20, 22, 23 |
| DETECT | 13, 14, 16 |
| RESPOND | 15-18 |
| RECOVER | 18, 19 |

## ISO/IEC 27001 notes
An ISMS needs scope, a risk-assessment method, a Statement of Applicability (SoA), internal audits and management review. This matrix feeds the SoA by indicating which Annex A concepts each technical control supports.

## CIS Controls implementation groups
NimbusPay (≈150 staff, cloud-hosted, sensitive data) should target **IG2** as its baseline, with selected IG3 practices for logging, incident response and data protection.
