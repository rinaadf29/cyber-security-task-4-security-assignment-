# Task 4: Cloud Security, Incident Response & Cybersecurity Capstone

**Modules:** 13-15 | **Level:** Capstone
**Role:** Lead Security Analyst, NimbusPay (fictional company)

> All content is fictional. No real systems were scanned, tested or attacked, and no real data was collected. This follows the task's security and ethical guidelines.

## Scenario summary
NimbusPay is a ~150-person fintech SaaS company migrating critical services to AWS. During a governance and security-maturity programme, a suspected incident is detected: an AWS access key committed to a public repository is used to enumerate and exfiltrate a customer-export S3 bucket and create a persistence IAM user. See [00-scenario.md](00-scenario.md).

## Repository index
| # | Deliverable | File |
|---|-------------|------|
| 0 | Scenario and assumptions | [00-scenario.md](00-scenario.md) |
| 1 | Secure cloud architecture | [01-cloud-architecture/architecture.md](01-cloud-architecture/architecture.md) |
| 1 | Threat model | [01-cloud-architecture/threat-model.md](01-cloud-architecture/threat-model.md) |
| 2 | Cloud security checklist | [02-cloud-security-checklist.md](02-cloud-security-checklist.md) |
| 3 | Framework / control mapping matrix | [03-framework-mapping.md](03-framework-mapping.md) |
| 4 | Incident-response plan | [04-incident-response-plan.md](04-incident-response-plan.md) |
| 5 | Incident timeline | [05-incident-analysis/timeline.md](05-incident-analysis/timeline.md) |
| 5 | IOCs and affected assets | [05-incident-analysis/iocs-and-affected-assets.md](05-incident-analysis/iocs-and-affected-assets.md) |
| 5 | Attack path and forensic analysis | [05-incident-analysis/attack-path.md](05-incident-analysis/attack-path.md) |
| 6 | Evidence-handling plan | [06-forensics/evidence-handling-plan.md](06-forensics/evidence-handling-plan.md) |
| 6 | Chain-of-custody template | [06-forensics/chain-of-custody-template.md](06-forensics/chain-of-custody-template.md) |
| 7 | DevSecOps plan | [07-devsecops-plan.md](07-devsecops-plan.md) |
| 8 | AI and IoT security assessment | [08-ai-iot-security-assessment.md](08-ai-iot-security-assessment.md) |
| 9 | 90-day roadmap | [09-roadmap-90-days.md](09-roadmap-90-days.md) |
| 10 | Career section | [10-career-plan.md](10-career-plan.md) |
| 11 | Executive presentation (Marp markdown) | [presentation/executive-deck.md](presentation/executive-deck.md) |
| 12 | Capstone report (15-25 pages) | [report/capstone-report.md](report/capstone-report.md) |

## How to view
- Diagrams use [Mermaid](https://mermaid.js.org/), which GitHub renders natively.
- The presentation is Marp-compatible markdown (VS Code "Marp for VS Code" extension, or `npx @marp-team/marp-cli presentation/executive-deck.md`).
- `report/build-report.sh` regenerates the capstone report (about 18 pages when exported) from the narrative sections plus key artifacts; all other deliverables are separate files above.

## Author
Rinad, Cybersecurity course, Task 4
