# DevSecOps Security Plan

**Goal:** make security automatic, early and continuous ("shift left" and "shield right") so incidents like the leaked-key event are prevented or caught within minutes.

## 1. Pipeline overview
```mermaid
flowchart LR
    A[Developer workstation<br/>pre-commit hooks] --> B[GitHub repo<br/>push protection, branch rules]
    B --> C[CI: build and test<br/>SAST, SCA, secrets, IaC scan]
    C --> D[Container build<br/>image scan, SBOM, signing]
    D --> E[Staging deploy<br/>DAST, integration tests]
    E --> F[Approval gate<br/>policy checks]
    F --> G[Production deploy<br/>OIDC role, signed image only]
    G --> H[Runtime<br/>GuardDuty, WAF, Config, alerts]
    H --> A
```

## 2. Source control
| Practice | Detail |
|----------|--------|
| Protected branches | Pull request required, 1-2 reviewers, status checks pass, no force-push on `main` |
| Secret prevention | GitHub secret scanning and **push protection** on; pre-commit `gitleaks`; `.env` in `.gitignore` templates |
| Commit signing | Signed commits for production repos |
| Repository policy | Company code only in company organisation; no public repos without review; CODEOWNERS for security-sensitive paths |
| Access | SSO-enforced, least privilege, quarterly review |

## 3. CI/CD pipeline
- **Authentication to AWS:** GitHub Actions uses OIDC federation to short-lived roles, scoped by repo and branch; no stored access keys.
- **Pipeline-as-code:** workflows reviewed like code; pin third-party actions to commit SHAs; least-privilege `GITHUB_TOKEN`.
- **Runners:** ephemeral runners; separate build and deploy permissions.
- **Policy as code:** OPA/Conftest or Checkov rules block insecure IaC (public buckets, `*` IAM, unencrypted storage).
- **Secrets in pipeline:** retrieved from Secrets Manager at runtime; masked in logs.

## 4. Dependency management
| Control | Tooling examples |
|---------|------------------|
| Software composition analysis | Dependabot, `npm audit`, `pip-audit`, OWASP Dependency-Check |
| Lock files and version pinning | `package-lock.json`, `requirements.txt` with hashes |
| SBOM generation | Syft or CycloneDX per build |
| Trusted registries | Private proxy/registry; block typosquatted packages |
| Update cadence | Critical CVEs patched within 7 days, high within 30 |

## 5. Security testing
| Stage | Test | Tool examples | Gate |
|-------|------|---------------|------|
| Commit | Secret scan | gitleaks | Block |
| Build | SAST | Semgrep, CodeQL | Block on high |
| Build | SCA | Dependabot, Trivy | Block on critical |
| Build | IaC scan | Checkov, tfsec | Block on high |
| Image | Container scan | Trivy, ECR scanning | Block on critical |
| Staging | DAST | OWASP ZAP (own staging only) | Warn/Block |
| Pre-release | Security unit and abuse-case tests | Pytest/Jest | Block |
| Periodic | Authorised penetration test | External vendor | Findings tracked |

All testing is performed only on systems NimbusPay owns or is authorised to assess.

## 6. Deployment
- Deploy only **signed** images from the trusted registry (Cosign/ECR signing, admission policy).
- Immutable infrastructure via IaC (Terraform/CloudFormation); drift detection with AWS Config.
- Blue/green or canary deployments with automated rollback.
- Change approval for production with security checks recorded.
- Separate accounts and roles for Dev, Staging, Prod.

## 7. Runtime and feedback loop
- Runtime alerts (GuardDuty, WAF, container runtime) feed back to backlog.
- Post-incident lessons create new pipeline checks (e.g., this incident adds mandatory secret scanning).
- Security champions in each team; secure-coding training twice a year.

## 8. Metrics
Percentage of repos with push protection, mean time to fix critical vulnerabilities, number of builds blocked by security gates, percentage of services with no static keys, SBOM coverage.

## 9. Roles
| Role | Responsibility |
|------|---------------|
| Developers | Fix findings, write secure code |
| Security champions | Triage findings, guide teams |
| Platform/DevOps | Own pipeline controls and tooling |
| Security team | Define policy, review exceptions, monitor |
