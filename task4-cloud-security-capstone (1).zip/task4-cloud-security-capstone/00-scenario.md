# Scenario and Assumptions

## Company profile: NimbusPay (fictional)
- Fintech SaaS providing payment-reconciliation dashboards to ~400 small-business customers.
- ~150 staff: 45 engineers, support, finance, sales; remote-first.
- Migrating from a colocation data centre to **AWS (ap-south-1 primary, ap-southeast-1 DR)**.
- Handles customer business and bank-reference data (treated as confidential and regulated).

## Representative workload (used throughout)
| Component | Technology |
|-----------|-----------|
| Web front end | React SPA on S3 + CloudFront + AWS WAF |
| API / services | Containerised microservices on ECS Fargate behind an ALB |
| Database | Amazon RDS PostgreSQL (Multi-AZ, encrypted) |
| Object storage | S3 buckets (app assets, customer exports, logs, backups) |
| Fraud-scoring | ML model on SageMaker endpoint fed by transaction features |
| IoT | ~300 card-reader / POS terminals reporting through AWS IoT Core |
| CI/CD | GitHub + GitHub Actions deploying to ECS |
| Identity | AWS IAM Identity Center federated to corporate IdP with MFA |

## The incident (summary)
A developer accidentally pushed a `.env` file containing a long-lived IAM access key to a **public personal GitHub repository**. Within hours the key was used from an unfamiliar IP to list and download a customer-export S3 bucket and to create a new IAM user for persistence. A CloudTrail alert on `CreateUser` from an unexpected source triggered the investigation. Detail is in `05-incident-analysis/`.

## Assumptions
- All names, IPs (documentation ranges 198.51.100.0/24, 203.0.113.0/24), account IDs and timestamps are fictional.
- Prior state: logging partially enabled, long-lived keys still in use by some pipelines, no secret scanning, no S3 Block Public Access at account level.
- Governance target: align with NIST CSF 2.0, ISO/IEC 27001:2022 concepts and CIS Controls v8.
