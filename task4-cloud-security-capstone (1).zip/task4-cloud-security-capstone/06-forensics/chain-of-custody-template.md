# Chain-of-Custody Template

## A. Case information
| Field | Value |
|-------|-------|
| Incident ID | NP-2026-014 |
| Case title | Leaked access key and S3 exfiltration |
| Authorised by | (name, role) |
| Forensics Lead | (name) |
| Date/time opened (UTC) | |

## B. Evidence register
| Evidence ID | Description | Source / location | Collected by | Date and time (UTC) | Method / tool | SHA-256 | Storage location |
|-------------|-------------|-------------------|--------------|--------------------|---------------|---------|-----------------|
| E-001 | CloudTrail export 2026-09-22 | Org trail bucket | | | AWS CLI | | evidence-bucket/E-001 |
| E-002 | S3 server access logs | Customer-exports logs prefix | | | AWS CLI | | evidence-bucket/E-002 |
| E-003 | IAM credential report and authorisation details | Prod account | | | AWS CLI | | evidence-bucket/E-003 |
| E-004 | GitHub repository clone with history | export-tools | | | git clone --mirror | | evidence-bucket/E-004 |
| E-005 | Alarm history and notification email | CloudWatch / mailbox | | | Export | | evidence-bucket/E-005 |
| E-006 | | | | | | | |

## C. Transfer log (one row per hand-off or access)
| Evidence ID | Released by (name / signature) | Received by (name / signature) | Date and time (UTC) | Purpose | Hash verified (Y/N) | Condition / notes |
|-------------|-------------------------------|-------------------------------|--------------------|---------|--------------------|------------------|
| | | | | | | |
| | | | | | | |

## D. Analysis log
| Evidence ID | Analyst | Working copy ID | Tool and version | Action performed | Date/time (UTC) | Result summary |
|-------------|---------|-----------------|------------------|------------------|-----------------|---------------|
| | | | | | | |

## E. Disposition
| Evidence ID | Final disposition (retain / return / destroy) | Authorised by | Date |
|-------------|----------------------------------------------|---------------|------|
| | | | |

## F. Declaration
I confirm the information above is accurate and that I handled the evidence according to the evidence-handling plan.

Name: ____________ Role: ____________ Signature: ____________ Date: ____________
