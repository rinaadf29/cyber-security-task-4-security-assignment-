# Digital Forensics Evidence-Handling Plan

**Scope:** cloud (AWS), SaaS (GitHub), endpoint and log evidence for NimbusPay incidents.
**Principles:** authorised access only, minimum necessary collection, preserve original, prove integrity, document everything. Evidence is limited to what the investigation requires.

## 1. Roles
| Role | Duty |
|------|------|
| Forensics Lead | Directs collection, owns chain-of-custody |
| Evidence Custodian | Stores and logs access to evidence |
| Collector | Performs acquisition using documented steps |
| Reviewer / Analyst | Works only on verified copies |
| Legal | Confirms authority, retention, and disclosure |

## 2. Order of volatility (collect most volatile first)
1. Memory and running-process state (for compute under investigation)
2. Network connections and session state
3. Cloud control-plane state (IAM entities, policies, security groups, current resource config)
4. Disk snapshots and volumes
5. Logs (CloudTrail, S3 access logs, VPC Flow, WAF, application logs)
6. Source-control history and SaaS audit logs
7. Backups and archives

## 3. Collection
| Evidence | Method | Notes |
|----------|--------|-------|
| CloudTrail events | Export from trail S3 bucket plus `lookup-events`; collect digest files | Include all regions; record time range in UTC |
| S3 server access logs | Copy relevant prefix to evidence bucket | Note best-effort delivery caveat |
| IAM state | Credential report, `get-account-authorization-details` output | Capture before and after containment |
| Disk (EBS) | Create snapshot, copy to Security account, share to forensic workstation | Never analyse the original volume |
| Container evidence | Preserve image digest, task definition, container logs | Quarantine task; do not delete |
| GitHub | Clone full repo with history; record commit hashes and audit-log entries | Takedown only after capture |
| Endpoint | Image per approved procedure; write blocker where physical disk | Only with authorisation |

## 4. Preservation
- Store evidence in a dedicated **Evidence** account/bucket: versioning on, S3 Object Lock (compliance mode), KMS encryption, no public access.
- Access limited to Forensics Lead and Custodian; all access logged (CloudTrail data events).
- Work on copies; originals remain untouched and sealed.
- Time-sync all collection systems; record timezone as UTC.
- Retention: keep for the period set by Legal (default 12 months, longer if legal hold).

## 5. Integrity
1. Compute SHA-256 hash of every acquired item at collection time.
2. Record hashes in the evidence register and a signed hash manifest.
3. Re-verify hashes on every transfer and before analysis.
4. Use CloudTrail log-file validation to prove log integrity.
5. Any hash mismatch is reported to the Forensics Lead immediately and logged.

Example commands (on authorised evidence only):
```
sha256sum cloudtrail-export-2026-09-22.json.gz > cloudtrail-export.sha256
sha256sum -c cloudtrail-export.sha256
aws cloudtrail validate-logs --trail-arn <ARN> --start-time <T1> --end-time <T2>
```

## 6. Documentation
- Contemporaneous notes: who, what, when (UTC), where, how, tool and version.
- Evidence register entry for each item (see template).
- Chain-of-custody form completed at every transfer.
- Analysis steps recorded so a third party could reproduce results.
- Photographs/screenshots of key console states with timestamp.

## 7. Legal and ethical considerations
- Collect only data needed for the investigation; avoid unnecessary personal data.
- Obtain authorisation (HR/Legal) before examining employee devices.
- Treat customer data in evidence as confidential; restrict access.
- Preserve ability to share evidence with law enforcement or regulators.

## 8. Handling checklist
- [ ] Incident ID and authority recorded
- [ ] Volatile data captured first
- [ ] Hash taken at collection
- [ ] Evidence copied to Evidence account
- [ ] Originals sealed / protected
- [ ] Chain-of-custody form started
- [ ] Analysis on verified copies only
- [ ] Final report cites evidence IDs
